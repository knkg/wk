//
//  SceneDelegate.h
//  welcome
//
//  Created by ms on 2020/12/12.
//  Copyright © 2020 ms. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

