//
//  ViewController.h
//  welcome
//
//  Created by ms on 2020/12/12.
//  Copyright © 2020 ms. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

