//
//  AppDelegate.h
//  FileUploadDownload
//
//  Created by kartik patel on 21/12/11.
//  Copyright (c) 2011 info@elegantmicroweb.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;

@property (retain, nonatomic) ViewController *viewController;

@end
