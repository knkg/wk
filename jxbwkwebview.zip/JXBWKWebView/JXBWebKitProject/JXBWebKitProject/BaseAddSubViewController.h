#import <UIKit/UIKit.h>
#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface BaseAddSubViewController : UIViewController

@property (nonatomic, strong) UIView *m_mainContentView;
@property (nonatomic, strong) UIView *m_topView;
@property (nonatomic, strong) UIView *m_bottomView;

- (AppDelegate *)appDelegate;
- (void)topBackgroundColor:(nullable UIColor *)color;
- (void)bottomBackgroundColor:(nullable UIColor *)color;

- (void)debugBoundView:(UIView *)view color:(UIColor *)color;

#pragma mark - Override
- (void)addSubViewFromParentView:(UIView *)parentView;
- (UIView *)mainContentSubView;

@end

NS_ASSUME_NONNULL_END
