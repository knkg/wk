
#import "BaseAddSubViewController.h"


@interface BaseAddSubViewController ()

@end

@implementation BaseAddSubViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CGRect rectScreen = [[UIScreen mainScreen] bounds];

    [self.view setFrame:rectScreen];
    [self.view setBackgroundColor:[UIColor whiteColor]];

    CGSize mainScreenSize = CGSizeZero;
    if ( @available(iOS 11.0, *) ) {
        UIWindow *window = [[UIApplication sharedApplication] keyWindow];
        CGFloat topPadding = window.safeAreaInsets.top;
        CGFloat bottomPadding = window.safeAreaInsets.bottom;
        CGFloat mainContentHeight = rectScreen.size.height - ( topPadding + bottomPadding );

        CGRect newRectMainScreen = CGRectMake(0.0f, topPadding, rectScreen.size.width, mainContentHeight);
        self.m_mainContentView = [[UIView alloc] initWithFrame:newRectMainScreen];

        mainScreenSize = CGSizeMake(rectScreen.size.width, mainContentHeight);

        if ( topPadding > 0.0f ) {
            self.m_topView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rectScreen.size.width, topPadding)];
            [self.m_topView setBackgroundColor:UIColorFromRGB(0xFFFFFF)];
            [self.view addSubview:self.m_topView];
        }
        
        if ( bottomPadding > 0.0f ) {
            self.m_bottomView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, rectScreen.size.height-bottomPadding, rectScreen.size.width, bottomPadding)];
            [self.m_bottomView setBackgroundColor:UIColorFromRGB(0xFFFFFF)];
            [self.view addSubview:self.m_bottomView];
        }
    }
    else {
        self.m_mainContentView = [[UIView alloc] initWithFrame:rectScreen];
        mainScreenSize = rectScreen.size;
    }

    [self.view addSubview:self.m_mainContentView];
    

    if ( [self respondsToSelector:@selector(addSubViewFromParentView:)] ) {
        [self addSubViewFromParentView:self.m_mainContentView];
    }
    

    if ( [self respondsToSelector:@selector(mainContentSubView)] ) {
        UIView *subView = [self mainContentSubView];
        [subView setFrame:CGRectMake(0.0f, 0.0f, self.m_mainContentView.frame.size.width, self.m_mainContentView.frame.size.height)];
        [self.m_mainContentView addSubview:subView];
    }
}

#pragma mark 
- (void)addSubViewFromParentView:(UIView *)parentView {
}

- (UIView *)mainContentSubView {
    return nil;
}

#pragma mark - User Method
- (AppDelegate *)appDelegate {
    AppDelegate *appDelegate = [CommonUtil appDelegate];
    return appDelegate;
}


- (void)debugBoundView:(UIView *)view color:(UIColor *)color {
    view.layer.borderColor = color.CGColor;
    view.layer.borderWidth = 2.0f;
}

- (void)topBackgroundColor:(nullable UIColor *)color {
    if ( self.m_topView ) {
        if ( color ) {
            [self.m_topView setBackgroundColor:color];
        }
        else {
            [self.m_topView setBackgroundColor:UIColorFromRGB(0xFFFFFF)];
        }
    }
}

- (void)bottomBackgroundColor:(nullable UIColor *)color {
    if ( self.m_bottomView ) {
        if ( color ) {
            [self.m_bottomView setBackgroundColor:color];
        }
        else {
            [self.m_bottomView setBackgroundColor:UIColorFromRGB(0xFFFFFF)];
        }
    }
}

@end
