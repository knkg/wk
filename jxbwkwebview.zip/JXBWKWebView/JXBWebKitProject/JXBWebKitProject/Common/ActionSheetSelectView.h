

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@class ActionSheetSelectItem;
typedef void (^ActionSheetItemSelectListener)(ActionSheetSelectItem *actionSheetSelectItem);

@interface ActionSheetSelectView : NSObject

@property (nonatomic, strong) NSArray *m_arrayItemList;
@property (nonatomic, strong) NSMutableArray *m_arrayActionSheetSelectItemList;

- (void)createWithActionSheetItemList:(NSArray *)arrayList
                           parentView:(UIScrollView *)parentView
                   onSelectedListener:(ActionSheetItemSelectListener)listener;

@end


@interface ActionSheetSelectItem : UIView

@property (nonatomic, weak) IBOutlet UIButton *m_btnClick;
@property (nonatomic, weak) IBOutlet UILabel *m_lbTitle;
@property (weak, nonatomic) IBOutlet UIButton *m_btnCheckboxRight;
@property (weak, nonatomic) IBOutlet UILabel *m_companySelectBGLine;

@property (nonatomic, assign) NSInteger m_itemIndex;
@property (nonatomic, copy) ActionSheetItemSelectListener m_listener;


- (void)onClickListener:(ActionSheetItemSelectListener)listener;


@end

NS_ASSUME_NONNULL_END
