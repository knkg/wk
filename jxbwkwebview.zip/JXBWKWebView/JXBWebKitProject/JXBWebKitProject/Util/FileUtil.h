

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface FileUtil : NSObject

#pragma mark - NSFileManager Handler

/**
 * @breif   도큐먼트경로
 * @return  NSString
 */
+ (NSString *)fileGetDocumentPath;

/**
 * @breif   파일/폴더명을 포함한 경로
 * @param   item 파일명/폴더명 경로
 * @return  NSString
 */
+ (NSString *)fileDocumentItemPath:(NSString *)item;

/**
 * @breif   파일/폴더 체크
 * @param   item 파일명/폴더명
 * @return  BOOL
 */
+ (BOOL)fileIsExistItem:(NSString *)item;

/**
 * @breif   파일/폴더 삭제
 * @param   item 파일명/폴더명
 * @return  BOOL
 */
+ (BOOL)fileDeleteItem:(NSString *)item;

/**
 * @breif   폴더생성
 * @param   item 폴더명
 * @return  None
 */
+ (BOOL)fileCreateDirectory:(NSString *)item;

/**
 * @breif   파일생성
 * @param   item 파일명
 * @param   contents 파일데이타
 * @return  None
 */
+ (BOOL)fileSaveItem:(NSString *)item contents:(NSData *)contents;


/**
 * @breif   아이템 불러오기
 * @param   path 아이템경로
 * @return  id
 */
+ (id)fileLoadItemPath:(NSString *)path;

/**
 * @breif   아이템 이동 또는 이름변경
 * @param   sourcePath 원본데이터 경로
 * @param   destPath   타겟데이터 경로
 * @return  BOOL
 */
+ (BOOL)fileMoveItemPath:(NSString *)sourcePath destPath:(NSString *)destPath;

/**
 * @breif   아이템 복사
 * @param   sourcePath 원본데이터 경로
 * @param   destPath   타겟데이터 경로
 * @return  BOOL
 */
+ (BOOL)fileCopyItemPath:(NSString *)sourcePath destPath:(NSString *)destPath;

/**
 * @breif   파일또는 폴더 목록 가져오기
 * @param   path 경로
 * @return  NSArray
 */
+ (NSArray *)fileArrayItemsPath:(NSString *)path;

#pragma mark - NSKeyedArchiver Handler

/**
 * @breif   NSKeyedArchiver
 * @param   object 저장데이터
 * @param   keyString 키값
 */
+ (void)archivedObject:(id)object forKey:(NSString *)keyString;

/**
 * @breif   NSKeyedArchiver
 * @param   keyString 키값
 * @return  id
 */
+ (id)archivedObjectForKey:(NSString *)keyString;

#pragma mark - UserDefaults Handler

/**
 * @breif   NSUserDefaults
 * @param   keyString 키
 */
+ (id)getObjectForKey:(NSString *)keyString;
    
/**
 * @breif   NSUserDefaults
 * @param   object 저장데이터
 * @param   keyString 키값
 */
+ (void)saveObject:(id)object forKey:(NSString *)keyString;

/**
 * @breif   NSUserDefaults
 * @param   keyString 키값
 */
+ (void)removeObjectForKey:(NSString *)keyString;
    
@end

NS_ASSUME_NONNULL_END
