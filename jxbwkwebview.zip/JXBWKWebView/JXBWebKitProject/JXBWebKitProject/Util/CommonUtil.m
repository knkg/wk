
#import "CommonUtil.h"
#import "AppDelegate.h"
#import "DeviceUtil.h"
#import "NSString+Addition.h"
#import "iToast.h"

@implementation CommonUtil

//+ (void)toastMessage:(NSString *)message {
//    [[[iToast makeText:message] setGravity:iToastGravityBottom] show];
//}

+ (UIImage *)imageFromView:(UIView *)view {
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, YES, 1.0f);
    [[view layer] renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *screenshot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return screenshot;
}

+ (UIImageView *)imageViewForScreenBlock {
    
    CGSize size = [UIScreen mainScreen].bounds.size;
    NSInteger width = (int) size.width;
    NSInteger height = (int) size.height;
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    switch ( width ) {
            
        case 320:
            if ( height >= 568 ) { //iPhone 5,5s
                [imageView setImage:[UIImage imageNamed:@"Default-568h"]];
            }
            else { //iPhone 4,4s
                [imageView setImage:[UIImage imageNamed:@"Default-480h"]];
            }
            
            break;
            
        case 375: {
            if ( height >= 812 ) { //iPhone X
                [imageView setImage:[UIImage imageNamed:@"Default-812h"]];
            }
            else { // iPhone 6,7,8
                [imageView setImage:[UIImage imageNamed:@"Default-667h"]];
            }
        } break;
            
        case 414: {
            if ( height >= 896 ) { // iPhone Xr, Xs
                [imageView setImage:[UIImage imageNamed:@"Default-896h"]];
            }
            else { //iPhone 6sp,7p,8p
                [imageView setImage:[UIImage imageNamed:@"Default-736h"]];
            }
        } break;
            
        case 768: { //iPad portrait
            [imageView setImage:[UIImage imageNamed:@"768x1024"]];
        } break;
            
        case 1024: { //iPad landscape
            [imageView setImage:[UIImage imageNamed:@"1024x768"]];
        } break;
            
        default:
            break;
    }
    
    return imageView;
}


+ (void)regsterTableViewCellNibName:(NSString *)nibName tableView:(UITableView *)tableView identifier:(NSString *)identifier {
    UINib *nib = [UINib nibWithNibName:nibName bundle:nil];
    [tableView registerNib:nib forCellReuseIdentifier:identifier];
}


+ (id) loadNibNamed:(NSString *)nibName className:(NSString *)className {
    NSArray *array = [[NSBundle mainBundle] loadNibNamed:nibName owner:nil options:nil];
    for ( id view in array ) {
        if ( [view isKindOfClass:NSClassFromString(className)] ) {
            return view;
        }
    }
    
    return nil;
}


+ (instancetype) storyboardName:(NSString *)storyboardName identifier:(nullable NSString *)identifier {
    UIStoryboard *stroyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
    
    id object;
    
    if ( identifier ) {
        object = [stroyboard instantiateViewControllerWithIdentifier:identifier];
    }
    else {
        object = [stroyboard instantiateInitialViewController];
    }
    
    return object;
}

+ (CGFloat)heightForTopPadding {
    if ( @available(iOS 11.0, *) ) {
        UIWindow *window = [[UIApplication sharedApplication] keyWindow];
        CGFloat topPadding = window.safeAreaInsets.top;
        return topPadding;
    }
    
    return 0.0f;
}

+ (CGFloat)heightForBottomPadding {
    if ( @available(iOS 11.0, *) ) {
        UIWindow *window = [[UIApplication sharedApplication] keyWindow];
        CGFloat bottomPadding = window.safeAreaInsets.bottom;
        return bottomPadding;
    }
    
    return 0.0f;
}

+ (CGFloat) heightForMainContent {
    CGFloat screenHeight = [[UIScreen mainScreen] bounds].size.height;

    if ( @available(iOS 11.0, *) ) {
        UIWindow *window = [[UIApplication sharedApplication] keyWindow];
        CGFloat topPadding = window.safeAreaInsets.top;
        CGFloat bottomPadding = window.safeAreaInsets.bottom;
        screenHeight = screenHeight - ( topPadding + bottomPadding );
    }
    
    return screenHeight;
}

+ (AppDelegate *)appDelegate {
    AppDelegate *appDelegate = (AppDelegate *) [UIApplication sharedApplication].delegate;
    return appDelegate;
}

+ (void)toastMessage:(NSString *)message {
    [iToast toastMessage:message];
}



@end
