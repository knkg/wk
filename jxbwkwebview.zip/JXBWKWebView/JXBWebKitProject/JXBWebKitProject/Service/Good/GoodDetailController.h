//
//  GoodDetailController.h
//  JXBWebKitProject
//
//  Created by 金修博 on 2018/8/4.
//  Copyright © 2018年 金修博. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodDetailController : UIViewController

@end
