//
//  TestWebViewController.h
//  JXBWebKitProject
//
//  Created by 金修博 on 2018/9/4.
//  Copyright © 2018年 金修博. All rights reserved.
//

#import "JXBWebViewController.h"

@interface TestWebViewController : JXBWebViewController

@end
