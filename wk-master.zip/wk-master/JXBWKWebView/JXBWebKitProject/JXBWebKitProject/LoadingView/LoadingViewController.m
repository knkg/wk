

#import "LoadingViewController.h"
#import "LoadingView.h"
#import "CertProgressView.h"

#import "AppDelegate.h"


@interface LoadingViewController()



@property (nonatomic, strong) UIImageView *m_imageLoadingView;
@property (nonatomic, strong) UIView *m_backgoundView;
@property (nonatomic, strong) UIView *m_blackTransparentView;

@property (nonatomic, assign) NSInteger m_countLoadingView;
@property (nonatomic, assign) BOOL m_isRunning;

@property (nonatomic, strong) LoadingView *m_loadingView;
@property (nonatomic, strong) CertProgressView *m_certProgressView;

@end

@implementation LoadingViewController



+ (instancetype)sharedInstance {
    static LoadingViewController *instance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    
    return instance;
}

- (instancetype)init {
    if ( self = [super init] ) {
        return self;
    }
    
    return nil;
}

- (CGRect)screenRect {
    return [[UIScreen mainScreen] bounds];
}

- (void)initialize {
    if ( !self.m_loadingView ) {
        self.m_loadingView =  (LoadingView *) [CommonUtil loadNibNamed:@"LoadingView" className:@"LoadingView"];
        self.m_loadingView.frame = [UIScreen mainScreen].bounds;
        
        UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
        [window addSubview:self.m_loadingView];
    }
}


- (void)showLoadingView {
    @synchronized (self) {
        if ( self.m_countLoadingView >= 0 ) {
            self.m_countLoadingView++;
        }
        
        if ( !self.m_isRunning ) {
            self.m_isRunning = YES;
            
            __weak typeof(self) weakSelf = self;
            dispatch_async(dispatch_get_main_queue(), ^{
                __strong typeof(weakSelf) strongSelf = weakSelf;

                [strongSelf initialize];
                [strongSelf.m_loadingView startLoading];
            });
        }
    }
}

- (void)hideLoadingView {
    @synchronized (self) {
        if ( self.m_countLoadingView > 0 ) {
            self.m_countLoadingView--;
        }
    
        //로딩요청한 수가 '0'이 되면 로딩뷰를 삭제함.
        if ( self.m_countLoadingView <= 0 ) {
            self.m_countLoadingView = 0;
            self.m_isRunning = NO;

            __weak typeof(self) weakSelf = self;
            dispatch_async(dispatch_get_main_queue(), ^{
                __strong typeof(weakSelf) strongSelf = weakSelf;
                
                [strongSelf.m_loadingView stopLoading];
                [strongSelf.m_loadingView removeFromSuperview];
                strongSelf.m_loadingView = nil;
                
            }); //mainQueue block
        }
    }
}

- (void)showCertProgressView {
    [self hideCertProgressView];
    
    self.m_certProgressView = (CertProgressView *) [CommonUtil loadNibNamed:@"LoadingView" className:@"CertProgressView"];
    self.m_certProgressView.frame = [UIScreen mainScreen].bounds;
    [self.m_certProgressView initialize];
    
    UIWindow *window = [[[UIApplication sharedApplication] delegate] window];
    [window addSubview:self.m_certProgressView];
    
    [self.m_certProgressView startProgress];
}

- (void)hideCertProgressView {
    if ( self.m_certProgressView ) {
        [self.m_certProgressView stopProgress];
        [self.m_certProgressView removeFromSuperview];
        self.m_certProgressView = nil;
    }
}

@end
