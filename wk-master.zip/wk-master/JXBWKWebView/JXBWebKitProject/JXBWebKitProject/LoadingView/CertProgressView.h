

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CertProgressView : UIView

@property (nonatomic, weak) IBOutlet UIImageView *progressImageView;
@property (nonatomic, weak) IBOutlet UIView *bgBlack;

- (void)initialize;
- (void)startProgress;
- (void)stopProgress;
    
    
@end

NS_ASSUME_NONNULL_END
