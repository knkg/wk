

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoadingView : UIView

@property (nonatomic, weak) IBOutlet UIImageView *progressImageView;
@property (nonatomic, weak) IBOutlet UIView *bgBlack;

- (void)startLoading;
- (void)stopLoading;

@end

NS_ASSUME_NONNULL_END
