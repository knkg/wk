

#import "CertProgressView.h"

static NSMutableArray *imageList;

@implementation CertProgressView

- (void)drawRect:(CGRect)rect {

    
}

- (void)initialize {
    self.progressImageView.frame = [UIScreen mainScreen].bounds;
    self.bgBlack.frame = [UIScreen mainScreen].bounds;
}

- (void)startProgress {


    if ( !imageList ) {
        imageList = [[NSMutableArray alloc] init];
        [imageList addObject:[UIImage imageNamed:@"progress_00000"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00001"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00002"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00003"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00004"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00005"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00006"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00007"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00008"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00009"]];
        [imageList addObject:[UIImage imageNamed:@"progress_00010"]];
  
    }
    
    [self.progressImageView setAnimationRepeatCount:0];
    [self.progressImageView setAnimationImages:imageList];
    
    [self.progressImageView startAnimating];
}


- (void)stopProgress {
    [self.progressImageView stopAnimating];
}


@end
