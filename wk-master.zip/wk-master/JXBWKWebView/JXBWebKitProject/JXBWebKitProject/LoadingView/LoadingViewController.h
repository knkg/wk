

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoadingViewController : NSObject

+ (instancetype)sharedInstance;

- (void)showLoadingView;
- (void)hideLoadingView;

- (void)showCertProgressView;
- (void)hideCertProgressView;

@end

NS_ASSUME_NONNULL_END
