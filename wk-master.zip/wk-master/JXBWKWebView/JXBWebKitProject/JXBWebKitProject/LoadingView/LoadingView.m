
#import "LoadingView.h"

@interface LoadingView()

@property (nonatomic, strong) NSMutableArray *m_arrImages;

@end

static NSMutableArray *imageList;


@implementation LoadingView

- (void)drawRect:(CGRect)rect {

}

- (void)startLoading {
    self.progressImageView.frame = [UIScreen mainScreen].bounds;
    self.bgBlack.frame = [UIScreen mainScreen].bounds;

    if ( !imageList ) {
        imageList = [[NSMutableArray alloc] init];
        [imageList addObject:[UIImage imageNamed:@"loading_00000"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00001"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00002"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00003"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00004"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00005"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00006"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00007"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00008"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00009"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00010"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00011"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00012"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00013"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00014"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00015"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00016"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00017"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00018"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00019"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00020"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00021"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00022"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00023"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00024"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00025"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00026"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00027"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00028"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00029"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00030"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00031"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00032"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00033"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00034"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00035"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00036"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00037"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00038"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00039"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00040"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00041"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00042"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00043"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00044"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00045"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00046"]];
        [imageList addObject:[UIImage imageNamed:@"loading_00047"]];
    }
    
    [self.progressImageView setAnimationRepeatCount:0];
    [self.progressImageView setAnimationImages:imageList];
    
    [self.progressImageView startAnimating];
}


- (void)stopLoading {
    [self.progressImageView stopAnimating];
}

@end
