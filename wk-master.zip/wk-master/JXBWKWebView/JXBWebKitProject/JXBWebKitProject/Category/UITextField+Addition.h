


#import <UIKit/UIKit.h>

typedef void (^UITextFieldNotificationListener)(NSString * _Nullable text);

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (Addition)

- (void) textFieldTextDidChangeNotificationListener:(UITextFieldNotificationListener)listener;
- (void) removeNotification;

@end

NS_ASSUME_NONNULL_END
