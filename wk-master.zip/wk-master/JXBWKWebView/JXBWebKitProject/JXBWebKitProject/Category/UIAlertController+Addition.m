

#import "UIAlertController+Addition.h"

@implementation UIAlertController (Addition)

+ (void) showMessageTitle:(NSString *)title
                  message:(NSString *)message
       confirmButtonTitle:(NSString *)confirmButtonTitle
        cancelButtonTitle:(NSString *)cancelButtonTitle
           buttonCallBack:(void(^)(UIAlertActionStyle alertStyle))buttonCallBack {
    
    
    NSMutableArray *arrayButtons = [[NSMutableArray alloc] init];
    
    if ( confirmButtonTitle && confirmButtonTitle.length > 0 ) {
        UIAlertAction *actionConfirm = [UIAlertAction actionWithTitle:confirmButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            if ( buttonCallBack ) {
                buttonCallBack(UIAlertActionStyleDefault);
            }
        }];
    
        [arrayButtons addObject:actionConfirm];
    }
    
    if ( cancelButtonTitle && cancelButtonTitle.length > 0 ) {
        UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            if ( buttonCallBack ) {
                buttonCallBack(UIAlertActionStyleCancel);
            }
        }];
        [arrayButtons addObject:actionCancel];
    }
    
    if ( arrayButtons && arrayButtons.count > 0 ) {
        [UIAlertController showAlertWithTitle:title message:message actions:arrayButtons];
    }
}

#pragma mark - Show Alert
+ (void) showAlertWithTitle:(NSString *)title message:(NSString *)message actions:(NSArray<UIAlertAction *> *)actions {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        for (UIAlertAction *action in actions) {
            [alert addAction:action];
        }
        [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alert animated:YES completion:nil];
    });
}

@end
