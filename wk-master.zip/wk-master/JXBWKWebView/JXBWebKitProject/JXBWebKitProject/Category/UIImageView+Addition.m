

#import "UIImageView+Addition.h"


@implementation UIImageView (Addition)

- (void)imageURL:(NSString *)imageURL {
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]];
        UIImage *image = [UIImage imageWithData:imageData];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self setImage:image];
            
        });
        
    });
}

- (void)startAnimationImageList:(NSArray *)imageList {
    
    [self setAnimationImages:imageList];
    
    self.animationDuration = 3.0f;
    self.animationRepeatCount = 0;
    [self startAnimating];
}


- (void)startDIDProgressAnimation {
    NSMutableArray *imageList = [[NSMutableArray alloc] init];
    [imageList addObject:[UIImage imageNamed:@""]];
    
    [self setAnimationImages:imageList];

    self.animationDuration = 3.0f;
    self.animationRepeatCount = 0;
    [self startAnimating];
}

@end
