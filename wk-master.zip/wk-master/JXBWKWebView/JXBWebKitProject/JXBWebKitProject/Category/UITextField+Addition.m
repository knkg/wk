
#import "UITextField+Addition.h"

@implementation UITextField (Addition) 

- (void) textFieldTextDidChangeNotificationListener:(UITextFieldNotificationListener)listener {
    [[NSNotificationCenter defaultCenter] addObserverForName:UITextFieldTextDidChangeNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification * _Nonnull note) {
        if ( listener ) {
            listener(self.text);
        }
    }];
}

- (void) removeNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidChangeNotification object:nil];
}


@end
