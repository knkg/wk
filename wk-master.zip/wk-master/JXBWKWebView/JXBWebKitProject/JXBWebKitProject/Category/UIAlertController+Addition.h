



#import <UIKit/UIKit.h>


@interface UIAlertController (Addition)


+ (void) showMessageTitle:(NSString *)title
                  message:(NSString *)message
       confirmButtonTitle:(NSString *)confirmButtonTitle
        cancelButtonTitle:(NSString *)cancelButtonTitle
           buttonCallBack:(void(^)(UIAlertActionStyle alertStyle))buttonCallBack;

@end
