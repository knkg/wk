

#import "NSString+Addition.h"
//#import "NSData+Addition.h"


@implementation NSString (Addition)

- (BOOL)validationForSecure {
    BOOL isValid = YES;
    
    //두개씩 잘라서 비교
    NSInteger maxLength = self.length - 2;
    for ( NSInteger i = 0; i <= maxLength; i++ ) {
        NSRange range = NSMakeRange(i, 2);
        NSString *findStr = [self substringWithRange:range];
        NSString *sourceStr = [self substringFromIndex:i+2];
        if ( [sourceStr containsString:findStr] ) {
            isValid = NO;
            break;
        }
    }
    
    //두개씩 잘라서 비교한 데이터가 정상이면 3새씩 잘라서 다시 비교
    if ( isValid ) {
        NSString *findStr = [self substringToIndex:3];
        NSString *sourceStr = [self substringFromIndex:3];
        if ( [sourceStr containsString:findStr] ) {
            isValid = NO;
        }
    }
    
    return isValid;
}

- (BOOL)validation {
    BOOL result = NO;
    
    if ( ![self isEqualToString:@""] && self.length > 0 ) {
        result = YES;
    }
    
    return result;
}

- (NSDictionary *)toDictionary {
    NSData *jsongData = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsongData options:0 error:&error];
    
    return dict;
}

- (NSString *)numberFormat {
    NSNumber *number = [NSNumber numberWithInteger:self.integerValue];
    NSString *numberFormat = [NSNumberFormatter localizedStringFromNumber:number numberStyle:NSNumberFormatterDecimalStyle];
    return numberFormat;
}

@end
