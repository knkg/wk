

#import <Foundation/Foundation.h>

@interface NSData (Category)
- (NSData*)AES128EncryptWithKey:(NSString*)key;
- (NSData*)AES128DecryptWithKey:(NSString*)key;
- (NSData*)AES256EncryptWithKey:(NSString*)key;
- (NSData*)AES256DecryptWithKey:(NSString*)key;
- (NSString *)toHexString;

//+ (NSData *)dataWithBase64EncodedString:(NSString *)string;
//- (NSString *)base64EncodedStringWithWrapWidth:(NSUInteger)wrapWidth;
//- (NSString *)base64EncodedString;

@end
