

#import "NSDate+Addition.h"



@implementation NSDate (Addition)

+ (NSDate *)makeDateFromYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day {
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    
//    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];

    
    NSString *stringYear = [NSString stringWithFormat:@"%d", (int)year];
    NSString *stringMonth = [NSString stringWithFormat:@"%02d", (int)month];
    NSString *stringDay = [NSString stringWithFormat:@"%02d", (int)day];

    NSString *dateString = [NSString stringWithFormat:@"%@-%@-%@", stringYear, stringMonth, stringDay];
    
    NSDate *date = [dateFormat dateFromString:dateString];
    return date;
}

- (NSString *)dateStringFormat:(nullable NSString *)format {
    
    if ( !format ) {
        format = @"yyyyMMdd";
    }
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:format];
    
    NSString *dateString = [dateFormat stringFromDate:self];
    return dateString;
}

- (NSDate *)dateFromAfterDay:(NSInteger)day {
    NSTimeInterval time = ( 3600 * 24 ) * day;
    NSDate *date = [self dateByAddingTimeInterval:time];
    
    return date;
}


@end
