

#import "UIView+Addition.h"

@implementation UIView (Addition)

- (void)addTopLineColor:(UIColor *)color lineWidth:(CGFloat)lineWidth {
    CALayer *addLayer = [[CALayer alloc] init];
    [addLayer setBackgroundColor:color.CGColor];
    [addLayer setFrame:CGRectMake(0.0f, 0.0f, self.bounds.size.width, lineWidth)];
    [self.layer addSublayer:addLayer];
}

- (void)addBottomLineColor:(UIColor *)color lineWidth:(CGFloat)lineWidth {
    CALayer *addLayer = [[CALayer alloc] init];
    [addLayer setBackgroundColor:color.CGColor];
    [addLayer setFrame:CGRectMake(0.0f, self.bounds.size.height - lineWidth, self.bounds.size.width, lineWidth)];
    [self.layer addSublayer:addLayer];
}

- (void)addLeftLineColor:(UIColor *)color lineWidth:(CGFloat)lineWidth {
    CALayer *addLayer = [[CALayer alloc] init];
    [addLayer setBackgroundColor:color.CGColor];
    [addLayer setFrame:CGRectMake(0.0f, 0.0f, lineWidth, self.bounds.size.height)];
    [self.layer addSublayer:addLayer];
}

- (void)addRightLineColor:(UIColor *)color lineWidth:(CGFloat)lineWidth {
    CALayer *addLayer = [[CALayer alloc] init];
    [addLayer setBackgroundColor:color.CGColor];
    [addLayer setFrame:CGRectMake(self.bounds.size.width - lineWidth, 0.0f, lineWidth, self.bounds.size.height)];
    [self.layer addSublayer:addLayer];
}

- (void)borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor cornerRadius:(CGFloat)cornerRadius {
    [self.layer setBorderWidth:borderWidth];
    [self.layer setBorderColor:borderColor.CGColor];
    [self.layer setCornerRadius:cornerRadius];
    [self.layer setMasksToBounds:YES];
}

@end
