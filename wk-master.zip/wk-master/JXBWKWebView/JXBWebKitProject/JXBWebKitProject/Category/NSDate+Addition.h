

#define DATE_FORMAT_YYYYMMDDHMIS @"yyyyMMddHHmmss"
#define DATE_FORMAT_YYYYMMDDHMI  @"yyyyMMddHHmm"

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDate (Addition)

+ (NSDate *)makeDateFromYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day;

- (NSString *)dateStringFormat:(nullable NSString *)format;

- (NSDate *)dateFromAfterDay:(NSInteger)day;


@end

NS_ASSUME_NONNULL_END
