


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (Addition)

- (void)addTopLineColor:(UIColor *)color lineWidth:(CGFloat)lineWidth;
- (void)addBottomLineColor:(UIColor *)color lineWidth:(CGFloat)lineWidth;
- (void)addLeftLineColor:(UIColor *)color lineWidth:(CGFloat)lineWidth;
- (void)addRightLineColor:(UIColor *)color lineWidth:(CGFloat)lineWidth;
- (void)borderWidth:(CGFloat)borderWidth borderColor:(UIColor *)borderColor cornerRadius:(CGFloat)cornerRadius;

@end

NS_ASSUME_NONNULL_END
