

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Addition)

- (BOOL)validationForSecure;
- (BOOL)validation;
- (NSDictionary *)toDictionary;
- (NSString *)numberFormat;


@end

NS_ASSUME_NONNULL_END
