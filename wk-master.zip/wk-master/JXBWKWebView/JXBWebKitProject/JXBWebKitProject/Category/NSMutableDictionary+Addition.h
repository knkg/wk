

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSMutableDictionary (Addition)

- (NSString *)toJSONString;

@end

NS_ASSUME_NONNULL_END
