

#import "ActionSheetSelectView.h"


@implementation ActionSheetSelectView


- (void)createWithActionSheetItemList:(NSArray *)arrayList parentView:(UIScrollView *)parentView onSelectedListener:(ActionSheetItemSelectListener)listener {
    
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    
    self.m_arrayActionSheetSelectItemList = [[NSMutableArray alloc] init];
    
    ActionSheetSelectItem *lastItemView;
    
    for ( NSInteger index = 0; index < arrayList.count; index++ ) {
        NSString *title = [arrayList objectAtIndex:index];
        ActionSheetSelectItem *item = (ActionSheetSelectItem *) [CommonUtil loadNibNamed:@"CommonView" className:@"ActionSheetSelectItem"];
        item.m_itemIndex = index;
        [item.m_lbTitle setText:title];
        item.m_btnCheckboxRight.hidden = YES;
        
        if(index == arrayList.count - 1){
            //[item.m_companySelectBGLine setBackgroundColor:UIColorFromRGB(0x0A000000)];
            [item.m_companySelectBGLine setBackgroundColor:[UIColor clearColor]];
        }
        [item onClickListener:^(ActionSheetSelectItem * _Nonnull actionSheetSelectItem) {
           
            for ( ActionSheetSelectItem *itm in self.m_arrayActionSheetSelectItemList ) {
                [itm.m_btnCheckboxRight setSelected:NO];
                itm.m_btnCheckboxRight.hidden = YES;
             }
            actionSheetSelectItem.m_btnCheckboxRight.hidden = NO;
            [actionSheetSelectItem.m_btnCheckboxRight setSelected:YES];
            
            if ( listener ) {
                listener(item);
            }
        }];
        
        CGFloat lastPosY = ( lastItemView ? CGRectGetMaxY(lastItemView.frame) : 0.0f );
        [item setFrame:CGRectMake(0.0f, lastPosY+1.0f, width, item.bounds.size.height)];
        [parentView addSubview:item];
        
        lastItemView = item;
        
        [self.m_arrayActionSheetSelectItemList addObject:item];
        
    }

    CGFloat height = CGRectGetMaxY(lastItemView.frame);
    [parentView setContentSize:CGSizeMake(width, height)];
}

@end


@implementation ActionSheetSelectItem

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)onClickListener:(ActionSheetItemSelectListener)listener {
    self.m_listener = listener;
}


- (IBAction)buttonTouchedClick:(UIButton *)sender {
    if ( self.m_listener ) {
        self.m_listener(self);
    }
}




@end
