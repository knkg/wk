

#import "BaseWebViewController.h"
#import "AppDelegate.h"

@interface BaseWebViewController ()

@property (nonatomic, strong) UIView *m_mainContentView;
@property (nonatomic, strong) UIView *m_topView;
@property (nonatomic, strong) UIView *m_bottomView;
@property (nonatomic, strong) UIView *m_leftView;
@property (nonatomic, strong) UIView *m_rightView;
@property (nonatomic, strong) HCSecureTextField *m_hcSecureTextField;

@end

@implementation BaseWebViewController

- (instancetype)init {
    if ( self = [super init] ) {
        return self;
    }
    
    return nil;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CGRect rectScreen = [[UIScreen mainScreen] bounds];
    NSLog(@"knkg x=%f, y=%f, width=%f, height=%f", rectScreen.origin.x, rectScreen.origin.y, rectScreen.size.width, rectScreen.size.height);
    [self.view setBackgroundColor:[UIColor whiteColor]];

    if ( @available(iOS 11.0, *) ) {
        UIWindow *window = [[UIApplication sharedApplication] keyWindow];
        CGFloat topPadding = window.safeAreaInsets.top;
        CGFloat leftPadding = window.safeAreaInsets.left;
        CGFloat rightPadding = window.safeAreaInsets.right;
        CGFloat bottomPadding = window.safeAreaInsets.bottom;

        CGFloat screenHeight = rectScreen.size.height - ( topPadding + bottomPadding );
        NSLog(@"knkg toppadding=%f bottompadding=%f", topPadding, bottomPadding);
        /*
         * 웹뷰를 붙일 뷰를 생성
         */
        CGRect mainScreenFrame = CGRectMake(0.0f, topPadding, rectScreen.size.width, screenHeight);
        UIView *mainContentView = [[UIView alloc] initWithFrame:mainScreenFrame];
        [self.view addSubview:mainContentView];
        self.m_mainContentView = mainContentView;
        
        /*
         * 상단여백
         */
        if ( topPadding > 0.0f ) {
            self.m_topView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, rectScreen.size.width, topPadding)];
            [self.m_topView setBackgroundColor:UIColorFromRGB(0xFFFFFF)];
            [self.view addSubview:self.m_topView];
        }
        
        /*
         * 하단여백
         */
        if ( bottomPadding > 0.0f ) {
            self.m_bottomView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, rectScreen.size.height-bottomPadding, rectScreen.size.width, bottomPadding)];
            [self.m_bottomView setBackgroundColor:UIColorFromRGB(0xFFFFFF)];
            [self.view addSubview:self.m_bottomView];
        }
    }
    else {
        UIView *mainContentView = [[UIView alloc] initWithFrame:rectScreen];
        [self.view addSubview:mainContentView];
        self.m_mainContentView = mainContentView;
    }
    
    self.m_webView = [[WebViewController alloc] initWithFrame:self.m_mainContentView.bounds configuration:nil];
   
    //padding
    //self.m_webView.layoutMargins = UIEdgeInsetsMake(20,20,20,20);
    //self.m_webView.scrollView.contentInset = UIEdgeInsetsMake(20, 20, 20, 20);
    
    NSLog(@"BaseWebViewController : %@", [NSNumber numberWithFloat:self.m_webView.frame.origin.y]);
    
    self.m_webView.m_webViewControllerDelegate = self;
    [self.m_mainContentView addSubview:self.m_webView];
    
    /*
     * 페이지 열기
     */
    [self webViewControllerRequestPage];
}

- (void)viewWillAppear:(BOOL)animated {
    
//    if([[[UIDevice currentDevice]systemVersion] floatValue]>=7){
//        CGRect viewBounds = [self.m_webView bounds];
//        viewBounds.origin.y = 20;
//        viewBounds.size.height = viewBounds.size.height - 20;
//        self.m_webView.frame = viewBounds;
//    }
    [super viewWillAppear:animated];
}

- (AppDelegate *)appDelegate {
    AppDelegate *appDelegate = [CommonUtil appDelegate];
    return appDelegate;
}

#pragma mark - 보안키패드
//- (void)showSecureKeypadWithRequireLength:(NSInteger)requireLength {
//    if ( !self.m_hcSecureTextField ) {
//        self.m_hcSecureTextField = [[HCSecureTextField alloc] initWithFrame:CGRectZero];
//
//        /*
//         * 보안키패드 텍스트필드 붙이기
//         */
//        [self.m_hcSecureTextField setKeyboardType:UIKeyboardTypeNumberPad];
//        [self.m_hcSecureTextField setBackgroundColor:[UIColor clearColor]];
//        [self.m_hcSecureTextField setTextColor:[UIColor clearColor]];
//        [self.m_hcSecureTextField createTransKeyWithDelegate:self target:self maxLength:requireLength requireLength:requireLength];
//        [self.view addSubview:self.m_hcSecureTextField];
//    }
//
//    TransKeyKeypadType keyboardType = ( self.m_hcSecureTextField.keyboardType == UIKeyboardTypeNumberPad ? TransKeyKeypadTypeNumberWithPasswordOnly : TransKeyKeypadTypeTextWithPassword );
//    [self.m_hcSecureTextField.m_usingTransKey setKeyboardType:keyboardType maxLength:requireLength minLength:requireLength];
//
//    [self.m_hcSecureTextField becomeFirstResponder];
//
//}

- (void)showSecureKeypadWithRequireLength:(NSInteger)requireLength {
    if ( self.m_hcSecureTextField ) {
        [self hideSecureKeypad];
    }
    
    self.m_hcSecureTextField = [[HCSecureTextField alloc] initWithFrame:CGRectZero];
    
    /*
     * 보안키패드 텍스트필드 붙이기
     */
    [self.m_hcSecureTextField setKeyboardType:UIKeyboardTypeNumberPad];
    [self.m_hcSecureTextField setBackgroundColor:[UIColor clearColor]];
    [self.m_hcSecureTextField setTextColor:[UIColor clearColor]];
    [self.m_hcSecureTextField createTransKeyWithDelegate:self target:self maxLength:requireLength requireLength:requireLength];
    [self.view addSubview:self.m_hcSecureTextField];
        
    [self.m_hcSecureTextField becomeFirstResponder];
}

- (void)hideSecureKeypad {
   if ( self.m_hcSecureTextField ) {
        [self.m_hcSecureTextField hideKeypad];
        [self.m_hcSecureTextField removeFromSuperview];
        self.m_hcSecureTextField = nil;
    }
}

#pragma mark - HCSecureTextFieldDelegate
- (void)secureTransKeyBeginEditing {
    self.m_hcSecureTextField.m_cipherText = nil;
    self.m_hcSecureTextField.m_dummyPasswordString = nil;
}

- (void)secureTransKeyShouldReturn {
    NSLog(@"secureTransKeyShouldReturn : %@", self.m_hcSecureTextField.m_cipherText);
    
    if ( self.m_hcSecureTextField.m_dummyPasswordString.length >= self.m_hcSecureTextField.m_requireLength ) {
        /*
         * 완료
         */
        [self.m_hcSecureTextField hideKeypad];
        NSString *encString = self.m_hcSecureTextField.m_cipherText;
        [self secureKeypadReturnData:encString];
    }
    else {
        //비밀번호 6자리를 입력해 주세요.
//        [HCAlertView alertWithTtile:@"알림" message:@"비밀번호 6자리를 입력해 주세요." confirmButtonTitle:@"확인" cancelButtontitle:nil completion:nil];
    }
}

- (void)secureTransKeyInput {
    NSLog(@"secureTransKeyInput dummyPasswordString : %@", self.m_hcSecureTextField.m_dummyPasswordString);
    NSLog(@"secureTransKeyInput cipherText: %@", self.m_hcSecureTextField.m_cipherText);
    
    NSString *dummyString = self.m_hcSecureTextField.m_dummyPasswordString;
    [self secureKeypadInputData:dummyString];
    
    /*
     * 비밀번호 6자리 이상 입력한 경우
     */
//    if ( self.m_hcSecureTextField.m_dummyPasswordString.length >= self.m_hcSecureTextField.m_requireLength ) {
//        /*
//         * 완료
//         */
//        [self.m_hcSecureTextField hideKeypad];
//        NSString *encString = self.m_hcSecureTextField.m_cipherText;
//        [self secureKeypadData:encString];
//    }
}

- (void)secureTransKeyDidEndCreating:(TransKey *)transKey {
    if(transKey != nil){
//        [transKey mTK_SetCompleteBtnHide:YES]; //입력완료 버튼 감춤
        NSLog(@"KeyPad Height : %lf", [transKey mTK_GetCurrentKeypadHeight]);
        NSLog(@"KeyPad x : %lf", [transKey mTK_GetCurrentKeypadX]);
    }
    
    CGFloat keyboardHeight = [transKey mTK_GetCurrentKeypadHeight];
    [self secureKeypadHeight:keyboardHeight];
}


- (void)secureTransKeyCancelKeypad {
    [self secureKeypadCancel];
    [self.m_hcSecureTextField hideKeypad];
}


#pragma mark - WebViewControllerDelegate
- (void)webViewMessageData:(NSDictionary *)data {
    [self webViewControllerReceiverWithData:data];
}

#pragma mark - Override function
- (void)webViewControllerReceiverWithData:(NSDictionary *)data {}
- (void)webViewControllerRequestPage {}

- (void)secureKeypadReturnData:(NSString *)data {}
- (void)secureKeypadInputData:(NSString *)data {}
- (void)secureKeypadCancel {}
- (void)secureKeypadHeight:(CGFloat)keyboardHeight {}

@end
