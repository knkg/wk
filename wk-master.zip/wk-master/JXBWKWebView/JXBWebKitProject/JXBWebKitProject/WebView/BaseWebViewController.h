
#import <UIKit/UIKit.h>
#import "WebViewController.h"
#import "HCSecureTextField.h"
#import "AppDelegate.h"


NS_ASSUME_NONNULL_BEGIN

@interface BaseWebViewController : UIViewController <WebViewControllerDelegate, HCSecureTextFieldDelegate>



@property (nonatomic, strong) WebViewController *m_webView;

@property (nonatomic, strong) NSString *m_urlString;
@property (nonatomic, strong) NSDictionary *parameters;


- (AppDelegate *)appDelegate;

/*
 * 보안키패드 올리기
 */
- (void)showSecureKeypadWithRequireLength:(NSInteger)requireLength;

/*
 * 보안키패드 올리기
 */
- (void)hideSecureKeypad;

/*
 * 웹뷰브릿지 리시버
 */
- (void)webViewControllerReceiverWithData:(NSDictionary *)data;
- (void)webViewControllerRequestPage;

- (void)secureKeypadReturnData:(NSString *)data;
- (void)secureKeypadInputData:(NSString *)data;
- (void)secureKeypadCancel;
- (void)secureKeypadHeight:(CGFloat)keyboardHeight;

@end

NS_ASSUME_NONNULL_END
