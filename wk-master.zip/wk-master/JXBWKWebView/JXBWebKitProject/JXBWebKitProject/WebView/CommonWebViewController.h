
#import "BaseWebViewController.h"
#import "SecurePasswordViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CommonWebViewController : BaseWebViewController<SecurePasswordViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UIView *m_contentView;

    
@end

NS_ASSUME_NONNULL_END
