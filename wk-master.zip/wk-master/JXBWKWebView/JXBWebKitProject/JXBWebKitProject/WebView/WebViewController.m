

#import "WebViewController.h"

#import "WebViewController+Delegate.h"
#import "NSString+Addition.h"
#import "SharedData.h"
#import "LoginController.h"


@implementation WebViewController


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

#pragma mark - Override
- (UIEdgeInsets)safeAreaInsets {
    return UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f);
}

#pragma mark - Init
- (instancetype)initWithFrame:(CGRect)frame configuration:(nullable WKWebViewConfiguration *)configuration {
    
    if ( !configuration ) {
        configuration = [self createConfiguration];
    }
    
    if ( self = [super initWithFrame:frame configuration:configuration] ) {
        
        [self setNavigationDelegate:self];
        [self setUIDelegate:self];
//        [self updateSizeFit];
        
        [self.scrollView setShowsVerticalScrollIndicator:NO];
        [self.scrollView setShowsHorizontalScrollIndicator:NO];
        
        return self;
    }

    return nil;
}

/**
* @breif    웹뷰초기화
*/
- (WKWebViewConfiguration *) createConfiguration {
    
    //캐시삭제
//    NSSet *websiteDataTypes = [NSSet setWithArray:@[WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache]];
//    NSDate *expire = [NSDate dateWithTimeIntervalSince1970:0];
//    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes modifiedSince:expire completionHandler:^{
//
//    }];
    
    WKUserContentController *userContentController = [[WKUserContentController alloc] init];
    [userContentController addScriptMessageHandler:self name:@"firebase"];
    
    WKWebViewConfiguration *webViewConfiguration = [[WKWebViewConfiguration alloc] init];
    [webViewConfiguration setUserContentController:userContentController];
    [webViewConfiguration.preferences setJavaScriptEnabled:YES];
    
    return webViewConfiguration;
}

//- (void)updateSizeFit {
//    CGFloat topPadding = [CommonUtil heightForTopPadding];
//    CGFloat bottomPadding = [CommonUtil heightForBottomPadding];
//    CGRect bounds = [UIScreen mainScreen].bounds;
//    CGFloat height = bounds.size.height - ( topPadding + bottomPadding );
//    CGRect frame = CGRectMake(0.0f, topPadding, bounds.size.width, height);
//
//    [self setFrame:frame];
//}

#pragma mark - KVO
- (void) registerOverver {
    [self addObserver:self forKeyPath:NSStringFromSelector(@selector(estimatedProgress)) options:NSKeyValueObservingOptionNew context:nil];
}

- (void) observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if ( [keyPath isEqualToString:NSStringFromSelector(@selector(estimatedProgress))] ) {
        NSLog(@"Loading progress : %f", self.estimatedProgress);
    }
}

#pragma mark - Custom Method

/**
* @breif    URL 이동
* @param    urlString 주소
*/
- (void) loadRequestURLString2:(NSString *)urlString {
    
    /*
     * 캐시삭제
     */
//    NSSet *websiteDataType = [NSSet setWithArray:@[WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache]];
//    NSDate *dateFfrom = [NSDate dateWithTimeIntervalSince1970:0];
//    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataType modifiedSince:dateFfrom completionHandler:^{
//
//    }];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    [self loadRequest:request];
}

- (void) loadRequestURLString:(NSString *)urlString {
    
    NSLog(@"1111");
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSMutableDictionary *dict = [NetAPIClient defaultParamers];
        NSLog(@"2222");
    if ( self.parameters ) {
        [dict addEntriesFromDictionary:self.parameters];
    }
    
    
    NSLog(@"3333");
    for ( NSString *key in dict.allKeys ) {
        NSString *val = [dict objectForKey:key];
        NSString *keypair = [NSString stringWithFormat:@"%@=%@", key, val];
        [array addObject:keypair];
    }
    
    NSString *bodyString = [array componentsJoinedByString:@"&"];
    NSLog(@"4444");
    NSLog(@"================================================");
    NSLog(@"Web Body Info : %@", bodyString);
    NSLog(@"================================================");
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:[bodyString dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPMethod:@"POST"];
    [request setURL:[NSURL URLWithString:urlString]];
    
    
    
//    /*
//     * 추가할 헤더변수 정의
//     */
//    NSMutableDictionary *appendHeaderInfo = nil;
//
//    NSString *accessToken = [SharedData sharedInstance].m_accessToken;
//    if ( [accessToken validation] ) {
//
//        LoginResultVO *vo = [[SharedData sharedInstance] getLoginResultVO];
//        NSString *userId = [LoginController getUserId];
//
//        appendHeaderInfo = [[NSMutableDictionary alloc] init];
//        [appendHeaderInfo setValue:([accessToken validation] ? accessToken : @"")       forKey:@"atoken"];
//        [appendHeaderInfo setValue:([vo.token validation] ? vo.token : @"")             forKey:@"rtoken"];
//        [appendHeaderInfo setValue:([vo.expiredDate validation] ? vo.expiredDate : @"") forKey:@"expiredDate"];
//        [appendHeaderInfo setValue:([userId validation] ? userId : @"")                 forKey:@"userId"];
//        [appendHeaderInfo setValue:([vo.grcoCd validation] ? vo.grcoCd : @"")           forKey:@"grcoCd"];
//        [appendHeaderInfo setValue:@"I" forKey:@"osClsf"];
//    }
//
//    /*
//     * 헤더값에 변화가 있으면 기존헤더 정보 추가해서 적용
//     */
//    if ( appendHeaderInfo ) {
//        NSDictionary *allHeaders = [request allHTTPHeaderFields];
//        [appendHeaderInfo addEntriesFromDictionary:allHeaders];
//        [request setAllHTTPHeaderFields:appendHeaderInfo];
//    }

    /*
     * 헤더에 저장할 Dictionary 생성
     */
    NSMutableDictionary *headerContainer = [[NSMutableDictionary alloc] init];
    
    /*
     *  처음에 NSURLRequest 생성시 정보 가쟈오기
     */
    NSDictionary *allHeaders = [request allHTTPHeaderFields];
    
    /*
     * 거래로그용 헤더정보
     */
    NSMutableDictionary *defaultHeaders = [NetAPIClient defaultHeaders];
    
    /*
     * 헤더설정
     */
    [headerContainer addEntriesFromDictionary:allHeaders];
    [headerContainer addEntriesFromDictionary:defaultHeaders];
    
    /*
     * 헤더정보 설정
     */
    [request setAllHTTPHeaderFields:headerContainer];
    
    
    NSLog(@"================================================");
    NSLog(@"Web Header Info : %@", headerContainer);
    NSLog(@"================================================");

    
    [self loadRequest:request];
}


- (void) loadRequestPostURLString:(NSString *)urlString {
    
    //https://dev-dcentric.hyundaicard.com:8443/moweb/cardUseInfo.do?csno=1740784897&crno=949026762CDC258392FBF34980E3D36C7F9A5C
    /*
     * 캐시삭제
     */
//    NSSet *websiteDataType = [NSSet setWithArray:@[WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache]];
//    NSDate *dateFfrom = [NSDate dateWithTimeIntervalSince1970:0];
//    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataType modifiedSince:dateFfrom completionHandler:^{
//
//    }];
    
    
    
    
    
    NSArray *array = [urlString componentsSeparatedByString:@"?"];
    NSString *targetUrlString = [array objectAtIndex:0];
    NSString *bodyString = [array objectAtIndex:1];

    NSLog(@"loadRequestPostURLString targetURL: %@", targetUrlString);
    NSLog(@"loadRequestPostURLString bodyString: %@", bodyString);

    NSData *bodyData = [bodyString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:bodyData];
    [request setHTTPMethod:@"POST"];
    [request setURL:[NSURL URLWithString:targetUrlString]];
    [self loadRequest:request];
}

//- (void) loadRequestPostURLString:(NSString *)urlString {
//
//    //https://dev-dcentric.hyundaicard.com:8443/moweb/cardUseInfo.do?csno=1740784897&crno=949026762CDC258392FBF34980E3D36C7F9A5C
//    /*
//     * 캐시삭제
//     */
////    NSSet *websiteDataType = [NSSet setWithArray:@[WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache]];
////    NSDate *dateFfrom = [NSDate dateWithTimeIntervalSince1970:0];
////    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataType modifiedSince:dateFfrom completionHandler:^{
////
////    }];
//
//    NSArray *array = [urlString componentsSeparatedByString:@"?"];
//    NSString *targetUrlString = [array objectAtIndex:0];
//    NSString *bodyString = [array objectAtIndex:1];
//
//    NSLog(@"loadRequestPostURLString targetURL: %@", targetUrlString);
//    NSLog(@"loadRequestPostURLString bodyString: %@", bodyString);
//
//    NSData *bodyData = [bodyString dataUsingEncoding:NSUTF8StringEncoding];
//
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
//    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
//    [request setHTTPBody:bodyData];
//    [request setHTTPMethod:@"POST"];
//    [request setURL:[NSURL URLWithString:targetUrlString]];
//    [self loadRequest:request];
//}

/**
 * @breif    Javascript 호출
 * @param    info  파라미터값
 */
//- (void) javascriptCall:(NSString *)function info:(NSDictionary *)info {
//    
//    NSError *error;
//    NSData *data = [NSJSONSerialization dataWithJSONObject:info options:0 error:&error];
//    NSString *jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
//    NSString *jsScript = [NSString stringWithFormat:@"%@('%@');", function, jsonString];
//    
//    NSLog(@"JS_CallFunction --> %@", jsScript);
//    
//    dispatch_async(dispatch_get_main_queue(), ^{
//        [self evaluateJavaScript:jsScript completionHandler:nil];
//    });
//}

/**
 * @breif    Javascript 호출
 * @param    string  파라미터값
 */
- (void) javascriptCall:(NSString *)function string:(NSString *)string {
    NSString *jsScript = [NSString stringWithFormat:@"%@('%@');", function, string];
    
    NSLog(@"JS_CallFunction --> %@", jsScript);
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self evaluateJavaScript:jsScript completionHandler:nil];
    });
    
}



@end
