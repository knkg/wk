

#import <UIKit/UIKit.h>
#import "BaseWebViewController.h"
#import "SecurePasswordViewController.h"
#import "IssuerInfoVO.h"


NS_ASSUME_NONNULL_BEGIN


typedef void(^UserVerComletion)(NSString * _Nullable ci);

@protocol UserVerificationViewControllerDelegate <NSObject>

@required

- (void)completeVerification:(id)vo;

@end


@interface UserVerificationViewController : BaseWebViewController <SecurePasswordViewControllerDelegate>

@property (nonatomic, weak) id<UserVerificationViewControllerDelegate> m_userVerificationViewControllerDelegate;

- (void)onUserVerCompletion:(UserVerComletion)completion;

@property (weak, nonatomic) id m_infoVo;

@end

NS_ASSUME_NONNULL_END
