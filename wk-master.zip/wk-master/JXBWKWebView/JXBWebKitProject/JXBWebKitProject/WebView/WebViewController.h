

#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol WebViewControllerDelegate <NSObject>

@required
- (void)webViewMessageData:(NSDictionary *)data;

@end

@interface WebViewController : WKWebView

@property (nonatomic, strong, nullable) WKWebView *m_openWebView;


@property (nonatomic, strong) NSDictionary *parameters;

/**
* @breif    초기화
*/
- (instancetype)initWithFrame:(CGRect)frame configuration:(nullable WKWebViewConfiguration *)configuration;


/*
 * 델리게이트
 */
@property (nonatomic, weak) id<WebViewControllerDelegate> m_webViewControllerDelegate;


/**
* @breif    옵져버 등록 ( KVO )
*/
//- (void) registerOverver;

/**
* @breif    URL 이동
* @param    urlString 주소
*/
- (void) loadRequestURLString:(NSString *)urlString;
- (void) loadRequestURLString2:(NSString *)urlString;

/**
* @breif    POST 방식 URL 이동
* @param    urlString 주소
*/
- (void) loadRequestPostURLString:(NSString *)urlString;

/**
 * @breif    Javascript 호출
 * @param   function  함수명
 * @param    info  파라미터값
 */
//- (void) javascriptCall:(NSString *)function info:(NSDictionary *)info;

/**
 * @breif    Javascript 호출
 * @param   function  함수명
 * @param    string  파라미터값
 */
- (void) javascriptCall:(NSString *)function string:(NSString *)string;

@end

NS_ASSUME_NONNULL_END
