
#import "CommonWebViewController.h"
#import "FileUtil.h"
#import "LoginController.h"
#import "HCAlertView.h"
#import "CorpCardTermsViewController.h"
#import "SharedData.h"
#import "UserVerificationViewController.h"

@interface CommonWebViewController ()

@property (nonatomic, strong) NSDictionary *m_receiveData;

@property (nonatomic, assign) CGFloat heightWebView;

@end

@implementation CommonWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //add
    //NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillShow:"), name:UIKeyboardWillShowNotification, object: nil);
    //NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillHide"), name:UIKeyboardWillShowNotification, object:nil);
    
}
//add
//func keyboardWillHide(){
//    UINavigationController?.setNavigationBarHidden(false, animated: true);
//}
////add
//func keyboardWillShow(notification: NSNotification){
//    UINavigationController?.setNavigationBarHidden(true, animated: true);
//    var info = notification.userInfo;
//    [var keyboardFrame:(CGRect = (info[UIKeyboardFrameEndUserInfoKey] as! NSValue.CGRectValue()))]
//}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)completePassword:(NSString *)password{
    NSLog(@"CommonWebView completePassword pass=%@", password);
    
    NSDictionary *dictReceiveData = self.m_receiveData;
    NSString *command = [dictReceiveData objectForKey:@"command"];
    NSDictionary *parameters = [dictReceiveData objectForKey:@"parameters"];
    
    if ( [command isEqualToString:@"secureKeypad"] ) {
        NSString *callbackDone = [parameters objectForKey:@"callbackDone"];
        
        //인증화면을 웹뷰 팝업으로 띄운경우 m_openWebView로 값을 넘김
        NSString *callJavascriptFunc = [NSString stringWithFormat:@"%@('%@')", callbackDone, password];
        [self.m_webView.m_openWebView evaluateJavaScript:callJavascriptFunc completionHandler:nil];
    }
}

#pragma mark - Custom Mehtod

- (void)buttonTouchedToabck {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)keyboardHideFrame {
    CGRect rect = self.m_webView.frame;
    rect.size.height = self.heightWebView;
    self.m_webView.frame = rect;
}

- (void)autoLogin {
    __weak typeof(self) weakSelf = self;
    
    [LoginController loginWithParams:nil completion:^(id  _Nullable result, BOOL success) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        
        if ( success ) {
            /*
             * 메인페이지로 이동
             */
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[strongSelf appDelegate].m_baseNavigationController popToRootViewControllerAnimated:YES];
            });
        }
        else {
            [HCAlertView alertWithTtile:@"로그인 실패" message:@"자동 로그인에 실패하였습니다.\n비밀번호로 로그인해 주세요." confirmButtonTitle:@"확인" cancelButtontitle:nil completion:^(BOOL confirm) {
                if ( confirm ) {
                    [[LoginController sharedInstance] loginPopupWithType:EN_AppLoginTypeDefault completion:^(id  _Nullable result, BOOL success) {
                        if ( success ) {
                            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                                [[strongSelf appDelegate].m_baseNavigationController popToRootViewControllerAnimated:YES];
                            });
                        }
                    }];
                }
            }];
        }
    }];
    
}

- (void)manualLogin {
    __weak typeof(self) weakSelf = self;

    [[LoginController sharedInstance] loginPopupWithType:EN_AppLoginTypeDefault completion:^(id  _Nullable result, BOOL success) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if ( success ) {
            /*
             * 메인페이지로 이동
             */
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [[strongSelf appDelegate].m_baseNavigationController popToRootViewControllerAnimated:YES];
            });
        }
    }];
    
}


#pragma mark - Override
- (void)webViewControllerReceiverWithData:(NSDictionary *)data {
    NSLog(@"common webViewControllerReceiverWithData : %@", data);
    
    self.m_receiveData = data;
    
    /*
     {
         command = back;
         name = "";
         parameters =     {
             ci = "agaBv97ypIUyioAmj5l+S2Lhz2RTxbsTSvAwu/l6XswITa7pVcmEhxKpkzqWIngTxmI7Xe1bTmDv03ZIUItxSg==";
             csno = 1740784897;
         };
     }
     {
         command = secureKeypad;
         name = "";
         parameters =     {
             callback = callBackKeyPad;
             callbackDone = callBackKeyPadDone;
             length = 3;
             tartget = "#txt01";
         };
     }
     
     jsvascript:callBackKeyPad('#txt01','000')
     javscript:callBackKeyPadDone('암호문')
     
     */
    
    NSString *command = [data objectForKey:@"command"];
//    NSString *name = [data objectForKey:@"name"];
    NSDictionary *parameters = [data objectForKey:@"parameters"];

    //비정상 접속일경우 종료처리
    if ( [command isEqualToString:EXIT_CODE] ) {
           [self hideSecureKeypad];
           NSString *str = @"비정상 접근이 확인되었습니다.\n앱을 종료합니다.";
           [HCAlertView alertWithTtile:@"알림" message:str confirmButtonTitle:@"확인" cancelButtontitle:nil completion:^(BOOL confirm) {
                exit(0);
            }
           ];
        return;
     }
   
    /*
     * 뒤로가기
     */
    if ( [command isEqualToString:@"back"] ) {
        [self hideSecureKeypad];
        [self.navigationController popViewControllerAnimated:YES];
    }

    //goMain
    if ( [command isEqualToString:@"goMain"] ) {
        NSLog(@"goMain called");
        id vc = [CommonUtil storyboardName:@"MainTab" identifier:nil];
        [[self appDelegate].m_baseNavigationController pushViewController:vc animated:YES];
    }
    if ( [command isEqualToString:@"management"] ) {
        id vc = [CommonUtil storyboardName:@"CardManage" identifier:@"CardManagerListViewController"];
        [[self appDelegate].m_baseNavigationController pushViewController:vc animated:YES];
    }
    else if ( [command isEqualToString:@"ARS"] ) {
        
        NSString *telno = [parameters objectForKey:@"telno"];
        
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"tel:%@", telno]];
        [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
    }else if ( [command isEqualToString:@"resData"] ) {
         NSString *shutdown = [[data objectForKey:@"parameters"] objectForKey:@"shutdown"];//shutdown
         //비정상 접속일경우 종료처리
         if ( [shutdown isEqualToString:EXIT_CODE] ) {
               NSString *str = @"비정상 접근이 확인되었습니다.\n앱을 종료합니다.";
               [HCAlertView alertWithTtile:@"알림" message:str confirmButtonTitle:@"확인" cancelButtontitle:nil completion:^(BOOL confirm) {
                    exit(0);
                }
               ];
         }
    }
    else if ( [command isEqualToString:@"secureKeypad"] ) {
        NSLog(@"CommonWebViewController secureKeypad");
        /*
         {
             command = secureKeypad;
             name = "";
             parameters =     {
                 callback = callBackKeyPad;
                 callbackDone = callBackKeyPadDone;
                 length = 3;
                 tartget = "#txt01";
             };
         }
         
         jsvascript:callBackKeyPad('#txt01','000')
         javscript:callBackKeyPadDone('암호문')
         
         */
        if(self.m_webView.m_openWebView == nil){
            if ( parameters ) {
                NSInteger length = [NSString stringWithFormat:@"%@", [parameters objectForKey:@"length"]].integerValue;
                [self showSecureKeypadWithRequireLength:length];

            }
        }else{
            NSString *inputText = [parameters objectForKey:@"inputText"];
            
            NSInteger length = [NSString stringWithFormat:@"%@", [parameters objectForKey:@"length"]].integerValue;
            SecurePasswordViewController *vc = (SecurePasswordViewController *) [CommonUtil storyboardName:@"SecurePassword" identifier:@"SecurePassword"];
            vc.m_securePasswordViewControllerDelegate = self;
            vc.m_passLength = length;
            vc.m_inputText = [NSString stringWithFormat:@"%@", inputText];
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            [self presentViewController:vc animated:YES completion:nil];
        }

    }else if ( [command isEqualToString:@"refreshToken"] ) {
        /*
         * 자동로그인 상태라면 메인으로
         */
        NSString *autoLoginUseYn = [FileUtil getObjectForKey:CONST_KEY_AUTO_LOGIN_USE_YN];
        if ( [autoLoginUseYn isEqualToString:@"Y"] ) {
            [self autoLogin];
        }
        else {
            [self manualLogin];
        }
    }
}

//- (void)webViewControllerRequestPage {
//    if ( self.parameters.allKeys.count > 0 ) {
//        NSMutableArray *arrayAppendQuery = [[NSMutableArray alloc] init];
//        for ( NSString *key in self.parameters.allKeys ) {
//            NSString *val = [self.parameters objectForKey:key];
//            [arrayAppendQuery addObject:[NSString stringWithFormat:@"%@=%@", key, val]];
//        }
//
//        if ( arrayAppendQuery.count > 0 ) {
//            NSString *queryString = [arrayAppendQuery componentsJoinedByString:@"&"];
//            NSString *urlString = [NSString stringWithFormat:@"%@%@?%@", CONST_SERVER_URL, self.m_urlString, queryString];
//            [self.m_webView loadRequestPostURLString:urlString];
//        }
//    }
//    else {
//        NSString *urlString = [NSString stringWithFormat:@"%@%@", CONST_SERVER_URL, self.m_urlString];
//
//        NSLog(@"CommonWebViewController : %@", urlString);
//        [self.m_webView loadRequestURLString:urlString];
//    }
//
//    /*
//     * 웹뷰 높이
//     */
//    self.heightWebView = self.m_webView.bounds.size.height;
//}

- (void)webViewControllerRequestPage {
    NSLog(@"knkg commonwebview  webViewControllerRequestPage");
    if ( self.parameters.allKeys.count > 0 ) {
        NSString *urlString = [NSString stringWithFormat:@"%@%@", CONST_SERVER_URL, self.m_urlString];
        self.m_webView.parameters = self.parameters;
        [self.m_webView loadRequestURLString:urlString];
    }
    else {
        NSString *urlString = [NSString stringWithFormat:@"%@%@", CONST_SERVER_URL, self.m_urlString];
        [self.m_webView loadRequestURLString:urlString];
    }
    
    /*
     * 웹뷰 높이
     */
    self.heightWebView = self.m_webView.bounds.size.height;
}


- (void)secureKeypadInputData:(NSString *)data {
    NSDictionary *dictReceiveData = self.m_receiveData;
    NSString *command = [dictReceiveData objectForKey:@"command"];
    NSDictionary *parameters = [dictReceiveData objectForKey:@"parameters"];
    
    if ( [command isEqualToString:@"secureKeypad"] ) {
        NSString *callbackFunc = [parameters objectForKey:@"callback"];
        NSString *tartget = [parameters objectForKey:@"tartget"];

        //jsvascript:callBackKeyPad('#txt01','*')
        
        NSString *callJavascriptFunc = [NSString stringWithFormat:@"%@(\"%@\",\"%@\")", callbackFunc, tartget, data];
        
        NSLog(@"javascript: %@", callJavascriptFunc);
        
        [self.m_webView evaluateJavaScript:callJavascriptFunc completionHandler:nil];
    }
}

- (void)secureKeypadReturnData:(NSString *)data {
    NSDictionary *dictReceiveData = self.m_receiveData;
    NSString *command = [dictReceiveData objectForKey:@"command"];
    NSDictionary *parameters = [dictReceiveData objectForKey:@"parameters"];
    
    if ( [command isEqualToString:@"secureKeypad"] ) {
        NSString *callbackDone = [parameters objectForKey:@"callbackDone"];

        //javscript:callBackKeyPadDone('암호문')
        
        NSString *callJavascriptFunc = [NSString stringWithFormat:@"%@(\"%@\")", callbackDone, data];

        NSLog(@"javascript: %@", callJavascriptFunc);

        [self.m_webView evaluateJavaScript:callJavascriptFunc completionHandler:nil];
    }
    
    [self keyboardHideFrame];
}

- (void)secureKeypadCancel {
    NSDictionary *dictReceiveData = self.m_receiveData;
    NSString *command = [dictReceiveData objectForKey:@"command"];
    NSDictionary *parameters = [dictReceiveData objectForKey:@"parameters"];
    
    if ( [command isEqualToString:@"secureKeypad"] ) {
        NSString *callbackFunc = [parameters objectForKey:@"callback"];
        NSString *tartget = [parameters objectForKey:@"tartget"];

        //jsvascript:callBackKeyPad('#txt01','***')
        
        NSString *callJavascriptFunc = [NSString stringWithFormat:@"%@(\"%@\",\"\")", callbackFunc, tartget];
        
        NSLog(@"javascript: %@", callJavascriptFunc);
        
        [self.m_webView evaluateJavaScript:callJavascriptFunc completionHandler:nil];
    }
    
    [self keyboardHideFrame];
}

- (void)secureKeypadHeight:(CGFloat)keyboardHeight {
    
    CGRect rect = self.m_webView.frame;
    rect.size.height = self.heightWebView - keyboardHeight;
    self.m_webView.frame = rect;
    
}

@end
