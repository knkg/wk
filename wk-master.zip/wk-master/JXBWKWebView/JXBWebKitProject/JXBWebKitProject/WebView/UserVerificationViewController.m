

#import "UserVerificationViewController.h"
#import "SharedData.h"
#import "NSString+Addition.h"

#import "HCAlertView.h"
#import "LoginController.h"
#import "CommonWebViewController.h"




@interface UserVerificationViewController ()

@property (nonatomic, copy) UserVerComletion m_comletion;
@property (nonatomic, strong) NSDictionary *m_receiveData;

@property (nonatomic, assign) CGFloat heightWebView;

@end


@implementation UserVerificationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
//    [self success];
}

- (void)completePassword:(NSString *)password{
    NSLog(@"completePassword pwas=%@", password);
    
    NSDictionary *dictReceiveData = self.m_receiveData;
    NSString *command = [dictReceiveData objectForKey:@"command"];
    NSDictionary *parameters = [dictReceiveData objectForKey:@"parameters"];
    
    if ( [command isEqualToString:@"secureKeypad"] ) {
        NSString *callbackDone = [parameters objectForKey:@"callbackDone"];
        
        NSString *callJavascriptFunc = [NSString stringWithFormat:@"%@('%@')", callbackDone, password];
        [self.m_webView evaluateJavaScript:callJavascriptFunc completionHandler:nil];
    }
}

#pragma mark - Custom Method

- (void)keyboardHideFrame {
    CGRect rect = self.m_webView.frame;
    rect.size.height = self.heightWebView;
    self.m_webView.frame = rect;
}

- (void)success {
    if ( [self.m_userVerificationViewControllerDelegate respondsToSelector:@selector(completeVerification:)] ) {
        [self.m_userVerificationViewControllerDelegate completeVerification:self.m_infoVo];
    }
}



- (void)onUserVerCompletion:(UserVerComletion)completion {
    self.m_comletion = completion;
}


#pragma mark - Override
- (void)webViewControllerReceiverWithData:(NSDictionary *)data {
    self.m_receiveData = data;
    NSLog(@"UserVeri webViewControllerReceiverWithData : %@", data);
    
    /*
     {
         command = back;
         name = "";
         parameters = "";
     }
     */
    
    
    NSString *command = [data objectForKey:@"command"];
//    NSString *name = [data objectForKey:@"name"];
    NSDictionary *parameters = [data objectForKey:@"parameters"];
    
    
    
    /*
     * 보안키패드
     */
    if ( [command isEqualToString:@"secureKeypad"] ) {
        /*
         {
             command = secureKeypad;
             name = "";
             parameters =     {
                 callback = callBackKeyPad;
                 callbackDone = callBackKeyPadDone;
                 length = 3;
                 tartget = "#txt01";
             };
         }
         
         jsvascript:callBackKeyPad('#txt01','000')
         javscript:callBackKeyPadDone('암호문')
         
         */
        NSLog(@"knkg UserVerificationViewController command=%@", command);
        if ( parameters ) {
            NSString *inputText = [parameters objectForKey:@"inputText"];
            
            NSInteger length = [NSString stringWithFormat:@"%@", [parameters objectForKey:@"length"]].integerValue;
            NSString *noticeText = [parameters objectForKey:@"noticeText"];
            NSLog(@" noticeText = %@", noticeText);
            SecurePasswordViewController *vc = (SecurePasswordViewController *) [CommonUtil storyboardName:@"SecurePassword" identifier:@"SecurePassword"];
            vc.m_securePasswordViewControllerDelegate = self;
            vc.m_passLength = length;
            vc.m_noticeText = noticeText;
            vc.m_inputText = [NSString stringWithFormat:@"%@", inputText];
            vc.modalPresentationStyle = UIModalPresentationFullScreen;
            [self presentViewController:vc animated:YES completion:nil];

        }
    }
    /*
     * 뒤로가기
     */
    else if ( [command isEqualToString:@"back"] ) {
        
        /*
         * 회원가입에서 진행한 경우
         */
        if ( [SharedData sharedInstance].m_idVerificationType == EN_IdVerificationTypeSignUp ) {
            NSMutableArray *arrayNewVC = [[NSMutableArray alloc] init];
            id targetVC;
            for (  UIViewController *vc in self.navigationController.viewControllers ) {
                if ( [vc isKindOfClass:[SignUpSelectCompanyViewController class]] ) {
                    targetVC = [CommonUtil storyboardName:@"SignUpAuthEmployee" identifier:nil];
                    [arrayNewVC addObject:targetVC];
                }
                else {
                    [arrayNewVC addObject:vc];
                }
            }
            
            if ( targetVC ) {
                [self.navigationController setViewControllers:arrayNewVC];
                [self.navigationController popToViewController:targetVC animated:YES];
            }
        }
        /*
         * 일반적인 경우
         */
        else {
            NSLog(@"call dismiss webview");
            //[[self appDelegate].m_baseNavigationController popViewControllerAnimated:YES];
            [self.navigationController popViewControllerAnimated:YES];
            //[self.navigationController dismissViewControllerAnimated:YES completion:nil];
        }
    }
    else {
        /*
         {
             command = resData;
             name = data;
             parameters =     {
                 ci = "agaBv97ypIUyioAmj5l+S2Lhz2RTxbsTSvAwu/l6XswITa7pVcmEhxKpkzqWIngTxmI7Xe1bTmDv03ZIUItxSg==";
                 csno = 1740784897;
             };
         }
         */
        if ( [command isEqualToString:@"resData"] ) {
            //NSString *ci = [[data objectForKey:@"parameters"] objectForKey:@"ci"];//ci
            NSString *bryyMndy = [[data objectForKey:@"parameters"] objectForKey:@"bryyMndy"];//생년월일
            //NSString *atoken = [[data objectForKey:@"parameters"] objectForKey:@"atoken"];//atoken
            NSString *shutdown = [[data objectForKey:@"parameters"] objectForKey:@"shutdown"];//shutdown
            [SharedData sharedInstance].m_birthday = bryyMndy;
            //[SharedData sharedInstance].m_atoken = atoken;
            //NSLog(@"resData atoken=%@",atoken);
            /*
             {
                 command = resData;
                 name = data;
                 parameters =     {
                     ci = "<null>";
                     csno = "";
                 };
             }
             */
            
            //비정상 접속일경우 종료처리
            if ( [shutdown isEqualToString:EXIT_CODE] ) {
                   NSString *str = @"비정상 접근이 확인되었습니다.\n앱을 종료합니다.";
                   [HCAlertView alertWithTtile:@"알림" message:str confirmButtonTitle:@"확인" cancelButtontitle:nil completion:^(BOOL confirm) {
                        exit(0);
                    }
                   ];
                return;
             }
            
            if ( [SharedData sharedInstance].m_idVerificationType == EN_IdVerificationTypeSignUp ) {
                
            }
            /*
             * 일반적인 경우
             */
            else {
                
            }
            
            if ( [self.m_userVerificationViewControllerDelegate respondsToSelector:@selector(completeVerification:)] ) {
                [self.m_userVerificationViewControllerDelegate completeVerification:self.m_infoVo];
            }
            
//            if ( self.m_comletion ) {
//                self.m_comletion(ci);
//            }
            
            /*
             * 본인인증 성공
             */
            
//            if ( [ci isKindOfClass:[NSNull class]] ) {
//                [HCAlertView alertWithTtile:@"본인인증 실패"
//                                    message:@"본인인증에 실패하였습니다.\n확인후 다시 시도해주세요."
//                         confirmButtonTitle:@"확인"
//                          cancelButtontitle:nil
//                                 completion:^(BOOL confirm) {
//
//                    if ( self.m_comletion ) {
//                        self.m_comletion(nil);
//                    }
//
//                }];
//
//                return;
//            }
//
//
//            if ( [ci validation] ) {
//                [[SharedData sharedInstance] getSignUpVO].ci = ci;
//                NSLog(@"knkg ci validatoin=%@", ci);
//                //
//                // 회원가입에서 진행할 경우
//                //
//                if ( [SharedData sharedInstance].m_idVerificationType == EN_IdVerificationTypeSignUp ) {
//
//                }
//                //
//                //  일반적인 경우
//                //
//                else {
//
//                }
//
//                if ( [self.m_userVerificationViewControllerDelegate respondsToSelector:@selector(completeVerification)] ) {
//                    [self.m_userVerificationViewControllerDelegate completeVerification];
//                }
//
//                if ( self.m_comletion ) {
//                    self.m_comletion(ci);
//                }
//            }
//            else {
//                [HCAlertView alertWithTtile:@"본인인증 실패"
//                                    message:@"본인인증에 실패하였습니다.\n확인후 다시 시도해주세요."
//                         confirmButtonTitle:@"확인"
//                          cancelButtontitle:nil
//                                 completion:^(BOOL confirm) {
//
//                    if ( self.m_comletion ) {
//                        self.m_comletion(nil);
//                    }
//
//                }];
//            }
        }
    }
}

- (void)secureView:(NSInteger)length {

            //SecurePasswordViewController *vc = (SecurePasswordViewController *) [CommonUtil storyboardName:@"SecurePassword" identifier:@"SecurePassword"];
            //vc.m_passLength = length;
            //vc.delegate = self;
            //[self.navigationController pushViewController:vc animated:YES];
    
     
            SecurePasswordViewController *vc = (SecurePasswordViewController *) [CommonUtil storyboardName:@"SecurePassword" identifier:@"SecurePassword"];
            vc.m_securePasswordViewControllerDelegate = self;

           /* [vc completePassword:^(NSString * _Nullable pass) {
                [vc dismissViewControllerAnimated:YES completion:^{
                    
                    NSLog(@"onPasswordCompletion : %@", pass);
                    
                    //하드코딩
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
                    [dict setObject:@"M-Point" forKey:@"cardName"];
                    [dict setObject:@"cardno" forKey:@"9490225978239169"];

                    CommonWebViewController *vc = [[CommonWebViewController alloc] initWithNibName:@"CommonWebViewController" bundle:nil];
                    vc.m_urlString = CONST_URL_RECEIVE_REG;
                    vc.parameters = dict;
                    [[strongSelf appDelegate].m_baseNavigationController pushViewController:vc animated:YES];

                }];
            }];*/
            vc.m_passLength = length;
            //[self.navigationController pushViewController:vc animated:YES];
            //[vc setModalPresentationStyle:UIModalPresentationFullScreen];
            [self presentViewController:vc animated:YES completion:nil];
    
     //if ( [self.m_securePasswordViewControllerDelegate respondsToSelector:@selector(completePassword:)] ) {
      //  [self.m_securePasswordViewControllerDelegate completePassword:@"1234"];
    // }
    
    
}


#pragma mark - Override
- (void)webViewControllerRequestPage {
    /*
     * 휴대폰 인증
     */
    SignUpVO *vo = [[SharedData sharedInstance] getSignUpVO];
    NSString *urlString = [NSString stringWithFormat:@"%@%@", CONST_SERVER_URL, CONST_URL_WEB_VER_PHONE];
    NSString *accessToken = [SharedData sharedInstance].m_accessToken;
    NSString *atoken = [SharedData sharedInstance].m_atoken;
 
    @try{
    self.m_webView.parameters = [NSDictionary dictionaryWithObjectsAndKeys:vo.grcoCd, @"vo.grcoCd", vo.empNo, @"vo.empNo", atoken, @"atoken", nil];
    [self.m_webView loadRequestURLString:urlString];
    }
    @catch (NSException *e){
        NSLog(@" exception=%@ %@", [e name], [e reason]);
    }
    //self.m_webView.parameters = [NSDictionary dictionaryWithObjectsAndKeys:vo.grcoCd, @"vo.grcoCd", vo.empNo, @"vo.empNo", accessToken, @"accessToken", nil];
    
    
    
             
    
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
//
//
//
//    SignUpVO *vo = [[SharedData sharedInstance] getSignUpVO];
//    NSString *url = [NSString stringWithFormat:@"%@%@", CONST_SERVER_URL, CONST_URL_WEB_VER_PHONE];
//    //NSString *detailPath = [NSString stringWithFormat:@"%@?grcoCd=%@&empNo=%@", url, vo.grcoCd, vo.empNo];
//    NSLog(@"kngk service webpath =%@ ", url);
//
//    NSString *post = [NSString stringWithFormat:@"grcoCd=%@&empNo=%@", vo.grcoCd, vo.empNo];
////    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
////    NSString *contentLength = [NSString stringWithFormat:@"%lu", (unsigned long)postData.length];
//
////    NSString *contentLength = [NSString stringWithFormat:@"%d", (int)[postData length]];
//
//    NSLog(@"kngk service post Data : %@ ", post);
//
//
//
//    [request setURL:[NSURL URLWithString:url]];
//    [request setHTTPMethod:@"POST"];
////    [request setHTTPBody:postData];
//
////    [request setValue:contentLength forHTTPHeaderField:@"Content-Length"];
//    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
//
//    [request setHTTPBody:[post dataUsingEncoding:NSUTF8StringEncoding]];
//
//
//
////    NSString *params = [NSString stringWithFormat:@"grcoCd=%@;empNo=%@",vo.grcoCd, vo.empNo];
////    [request addValue:params forHTTPHeaderField:@"Cookie"];
////    [request setValue:vo.grcoCd forHTTPHeaderField:@"grcoCd"];
////    [request setValue:vo.empNo forHTTPHeaderField:@"empNo"];
//
//    [self.m_webView loadRequest:request];
//
//    NSLog(@"");
//
//    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
//    [dict setObject:@"grcoCd" forKey:vo.grcoCd];
//    [dict setObject:@"empNo" forKey:vo.empNo];
    
//    NSString *detailPath = [NSString stringWithFormat:@"%@%@?grcoCd=%@&empNo=%@", CONST_SERVER_URL, CONST_URL_WEB_VER_PHONE, vo.grcoCd, vo.empNo];
//    NSLog(@"detailview=%@", detailPath);
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
//    [request setHTTPMethod:@"POST"];
//    [request setURL:[NSURL URLWithString:detailPath]];
//    [self.m_webView loadRequest:request];
    
//    NSString *url = [NSString stringWithFormat:@"%@%@", CONST_SERVER_URL, CONST_URL_WEB_VER_PHONE];
//    CommonWebViewController *vc = [[CommonWebViewController alloc] initWithNibName:@"CommonWebViewController" bundle:nil];
//    vc.m_urlString = url;
//    vc.parameters= dict;
//    [self.navigationController pushViewController:vc animated:YES];
    

////    NSString *bodyString = [array objectAtIndex:1];
////    NSData *bodyData = [bodyString dataUsingEncoding:NSUTF8StringEncoding];
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
//
//    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
//    //NSString *body = [NSString stringWithFormat:@"{\"grcoCd\" = \"%@\";\"empNo\" = \"%@\";}", vo.grcoCd, vo.empNo];
//    NSString *body = [NSString stringWithFormat:@"grcoCd=A26"]; //, vo.grcoCd, vo.empNo];
//    //NSData *bodyData = [body dataUsingEncoding:NSUTF8StringEncoding];
//    [request setHTTPBody:bodyData];
//    [request setHTTPMethod:@"POST"];
//    [request setURL:[NSURL URLWithString:url]];
//    [self.m_webView loadRequest:request];
    
//    NSString *body = [NSString stringWithFormat:@"grcoCd=A26"];
//    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
//    [request setHTTPMethod:@"POST"];
//    [request setURL:[NSURL URLWithString:url]];
//    [request setHTTPBody: [body dataUsingEncoding:NSUTF8StringEncoding]];
//    [self.m_webView loadRequest:request];
//    NSLog(@" request HTTPBody=%@",request.HTTPBody.description);
//    NSLog(@" request mainDocumentURL=%@",request.mainDocumentURL);
  
        
        
        
        
    
    
    
//
//    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
//    [dict setObject:@"grcoCd" forKey:vo.grcoCd];
//    [dict setObject:@"empNo" forKey:vo.empNo];
//
//    self.m_webView.parameters = dict;
//
//    [self.m_webView loadRequestURLString:url];
    
    
//    CommonWebViewController *vc1 = [[CommonWebViewController alloc] initWithNibName:@"CommonWebViewController" bundle:nil];
//    vc1.m_urlString = url;
    //[self.m_webView loadRequestURLString:url];
    //[self presentViewController:vc1 animated:YES completion:nil];
     //[self pushViewController:vc1 animated:YES];
    
//    NSMutableURLRequest *phoneReq = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
//    [phoneReq setHTTPMethod:@"POST"];
//    [phoneReq setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
//    [phoneReq setValue:vo.grcoCd forHTTPHeaderField:@"grcoCd"];
//    [phoneReq setValue:vo.empNo forHTTPHeaderField:@"empNo"];
//    NSString *body = [NSString stringWithFormat:@"{\"grcoCd\" = \"%@\";\"empNo\" = \"%@\";}", vo.grcoCd, vo.empNo];
//    NSData *bodyData = [body dataUsingEncoding:NSUTF8StringEncoding];
//    [phoneReq setHTTPBody:bodyData];
//    [self.m_webView loadRequest:phoneReq];
    
//    NSString *URLString = url;
//    NSDictionary *parameters = [[NSDictionary alloc] init];
//    [parameters setValue:@"1111" forKey:@"grcoCd"];
//    [parameters setValue:@"2222" forKey:@"empNo"];

    //NSMutableURLRequest *request = [self.requestSerializer requestWithMethod:@"POST" URLString:[[NSURL URLWIthString:URLString relativeURL:nil] absoluteString] parameters:parameters error:nil];
    
//    AFHTTPRequestOperation *operation = [self HTTPRequestOperationWithRequest:request success:success failer:failer];
//    [self.operationQueue addOperatoin:operation];
//

    //NSLog(@"knkg body=%@", body);
    //[self.m_webView loadRequest:request];
    //Alamofire.request(.POST, webServicesURL, parameters: parameters, encoding:.JOSN, headers:self.headers);
    
    
    
}

- (void)secureKeypadInputData:(NSString *)data {
    NSDictionary *dictReceiveData = self.m_receiveData;
    NSString *command = [dictReceiveData objectForKey:@"command"];
    NSDictionary *parameters = [dictReceiveData objectForKey:@"parameters"];
    
    if ( [command isEqualToString:@"secureKeypad"] ) {
        NSString *callbackFunc = [parameters objectForKey:@"callback"];
        NSString *tartget = [parameters objectForKey:@"tartget"];

        //jsvascript:callBackKeyPad('#txt01','000')
        
        NSString *callJavascriptFunc = [NSString stringWithFormat:@"%@('%@','%@')", callbackFunc, tartget, data];
        [self.m_webView evaluateJavaScript:callJavascriptFunc completionHandler:nil];
    }
}

- (void)secureKeypadReturnData:(NSString *)data {
    NSDictionary *dictReceiveData = self.m_receiveData;
    NSString *command = [dictReceiveData objectForKey:@"command"];
    NSDictionary *parameters = [dictReceiveData objectForKey:@"parameters"];
    
    if ( [command isEqualToString:@"secureKeypad"] ) {
        NSString *callbackDone = [parameters objectForKey:@"callbackDone"];

        //javscript:callBackKeyPadDone('암호문')
        
        NSString *callJavascriptFunc = [NSString stringWithFormat:@"%@('%@')", callbackDone, data];
        [self.m_webView evaluateJavaScript:callJavascriptFunc completionHandler:nil];
    }
    
}

- (void)secureKeypadCancel {
    NSDictionary *dictReceiveData = self.m_receiveData;
    NSString *command = [dictReceiveData objectForKey:@"command"];
    NSDictionary *parameters = [dictReceiveData objectForKey:@"parameters"];
    
    if ( [command isEqualToString:@"secureKeypad"] ) {
        NSString *callbackFunc = [parameters objectForKey:@"callback"];
        NSString *tartget = [parameters objectForKey:@"tartget"];

        //jsvascript:callBackKeyPad('#txt01','***')
        
        NSString *callJavascriptFunc = [NSString stringWithFormat:@"%@(\"%@\",\"\")", callbackFunc, tartget];
        
        NSLog(@"javascript: %@", callJavascriptFunc);
        
        [self.m_webView evaluateJavaScript:callJavascriptFunc completionHandler:nil];
    }
    
    [self keyboardHideFrame];
}

- (void)secureKeypadHeight:(CGFloat)keyboardHeight {
    
    CGRect rect = self.m_webView.frame;
    rect.size.height = self.heightWebView - keyboardHeight;
    self.m_webView.frame = rect;
    
}

@end
