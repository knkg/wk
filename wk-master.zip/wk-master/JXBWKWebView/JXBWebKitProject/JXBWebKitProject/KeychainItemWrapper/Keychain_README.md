KeychainItemWrapper
===================

The KeychainItemWrapper original code from Apple, with ARC and NSDictionary support

You will be able to do:
[_keychainItem setObject:mydictionary forKey:(__bridge id)kSecValueData];