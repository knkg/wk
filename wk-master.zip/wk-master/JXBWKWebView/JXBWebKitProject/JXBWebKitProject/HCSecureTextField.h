

#import <UIKit/UIKit.h>
#import "TransKey.h"

NS_ASSUME_NONNULL_BEGIN


@class HCSecureTextField;

@protocol HCSecureTextFieldDelegate <NSObject>

@required
- (void)secureTransKeyBeginEditing;
- (void)secureTransKeyShouldReturn;
- (void)secureTransKeyInput;

@optional
- (void)secureTransKeyEndEditing;
- (void)secureTransKeyCancelKeypad;
- (void)secureTransKeyDidEndCreating;
- (void)secureTransKeyDidEndCreating:(TransKey *)transKey;

@end


@interface HCSecureTextField : UITextField <TransKeyDelegate, UITextFieldDelegate>


@property (nonatomic, weak) id<HCSecureTextFieldDelegate> m_hcSecureTextFieldDelegate;


@property (nonatomic, strong, nullable) TransKey *m_usingTransKey;

/*
 * 암호화 데이터
 */
@property (nonatomic, strong, nullable) NSString *m_cipherText;

/*
 * 원문
 */
@property (nonatomic, strong, nullable) NSString *m_originText;

/*
 * 테스트필드에 입력될 Dummy텍스트
 */
@property (nonatomic, strong, nullable) NSMutableString *m_dummyPasswordString;

/*
 * 최대길이
 */
@property (nonatomic, assign) NSInteger m_maxLength;

/*
 * 필수길이
 */
@property (nonatomic, assign) NSInteger m_requireLength;

/*
 * 노출유무
 */
@property (nonatomic, assign) BOOL m_isShow;


/*
 * 보인키패드 생성
 */
- (void)createTransKeyWithDelegate:(id<HCSecureTextFieldDelegate>)delegate
                            target:(id)target
                         maxLength:(NSInteger)maxLength
                     requireLength:(NSInteger)requireLength;

/*
 * 보인키패드 생성
 */
- (void)createTransKeyWithDelegateWeb:(id<HCSecureTextFieldDelegate>)delegate
                            target:(id)target
                         maxLength:(NSInteger)maxLength
                     requireLength:(NSInteger)requireLength;

/*
 * 초기화
 */
- (void)resetTransKey;

/*
 * 보안키패드 삭제
 */
- (void)clean;

/*
 * 보안키패드 노출
 */
- (void)showKeypad;

/*
 * 보안키패드 숨기기
 */
- (void)hideKeypad;
    
@end

NS_ASSUME_NONNULL_END
