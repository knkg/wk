
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ToastViewController : UIView

+ (void)showMessage:(NSString *)message completion:(nullable void(^)(void))completion;

@end

NS_ASSUME_NONNULL_END
