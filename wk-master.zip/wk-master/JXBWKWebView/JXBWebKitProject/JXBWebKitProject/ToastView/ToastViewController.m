

#import "ToastViewController.h"
#import "ToastView.h"
#import "AppDelegate.h"

@implementation ToastViewController

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

+ (void)showMessage:(NSString *)message completion:(void(^)(void))completion {
    AppDelegate *appDelegate = (AppDelegate *) [UIApplication sharedApplication].delegate;
    CGRect bounds = [[UIScreen mainScreen] bounds];

    ToastView *toast = [CommonUtil loadNibNamed:@"ToastView" className:@"ToastView"];
    [toast.layer setCornerRadius:toast.bounds.size.height/12.0f];
    [toast.layer setMasksToBounds:YES];
    [toast.lbMessage setText:message];
    
    CGFloat posY = bounds.size.height - ( [CommonUtil heightForBottomPadding] + 30.0f + toast.bounds.size.height );
    
    CGRect rect = toast.frame;
    rect.origin.x = 7.0f;
    rect.origin.y = posY;
    rect.size.width = bounds.size.width - ( 7.0f * 2.0f );
    toast.frame = rect;
    
    [toast setAlpha:0.0f];
    [appDelegate.window addSubview:toast];
    
    [UIView animateWithDuration:1.0 animations:^{
        [toast setAlpha:0.7f];
    } completion:^(BOOL finished) {

        [UIView animateWithDuration:1.0 animations:^{
            [toast setAlpha:0.0f];
        } completion:^(BOOL finished) {

            [toast removeFromSuperview];

            if ( completion ) {
                completion();
            }

        }];
    }];
}



@end
