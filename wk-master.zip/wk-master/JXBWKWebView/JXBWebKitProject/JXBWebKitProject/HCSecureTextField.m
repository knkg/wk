

#import "HCSecureTextField.h"
#import "NSString+Addition.h"



@implementation HCSecureTextField

- (instancetype)initWithFrame:(CGRect)frame {
    if ( self = [super initWithFrame:frame] ) {
        [self setDelegate:self];
        [self setSecureTextEntry:YES];
        
        return self;
    }
    
    return nil;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    [self setDelegate:self];
    [self setSecureTextEntry:YES];
}

#pragma mark - Custom Mehtod
- (void)resetTransKey {
    self.m_dummyPasswordString = [[NSMutableString alloc] init];
    self.m_cipherText = nil;
    [self setText:@""];
    [self.m_usingTransKey clear];
}

#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    /*
     * 데이터 초기화
     */
    [self resetTransKey];
    
    /*
     * 보안키패드 올리기
     */
    self.m_isShow = YES;
    [self.m_usingTransKey TranskeyResignFirstResponder];
    [self.m_usingTransKey TranskeyBecomeFirstResponder];
    
    
    return NO;
}


#pragma mark - TransKey Mehtod

/*
 * 보안키패드 생성
 */
- (void)createTransKeyWithDelegate:(id<HCSecureTextFieldDelegate>)delegate target:(UIViewController *)target maxLength:(NSInteger)maxLength requireLength:(NSInteger)requireLength {
    
    [self setDelegate:self];
    [self setSecureTextEntry:YES];
    
    self.m_hcSecureTextFieldDelegate = delegate;
    self.m_requireLength = requireLength;
    self.m_maxLength = maxLength;
    
    /*
     * 초기화
     */
    unsigned char iv[16] = { 'M', 'o', 'b', 'i', 'l', 'e', 'T', 'r' , 'a', 'n', 's', 'K', 'e', 'y', '1', '0' };
    NSData *secureKey = [[NSData alloc] initWithBytes:iv length:16];
    
   
    //Transkey Alloc
    CGRect frame = CGRectZero;//CGRectMake(20.0, 400, 281.0, 44.0);//CGRectZero;
    
    TransKey *transKeyPad = [[TransKey alloc] initWithFrame:frame];
    [transKeyPad setBackgroundColor:[UIColor blackColor]];
    transKeyPad.delegate = self;
    transKeyPad.parent = target;
    [target.view addSubview:transKeyPad];
    
    
    // 키값 세팅
    [transKeyPad setSecureKey:secureKey];
    
    // 가로, 세로 지원 설정
    [transKeyPad mTK_SupportedByDeviceOrientation:SupportedByDevicePortrait];
    
    // 키보드 타입 설정
    TransKeyKeypadType keyboardType = ( self.keyboardType == UIKeyboardTypeNumberPad ? TransKeyKeypadTypeNumberWithPasswordOnly : TransKeyKeypadTypeTextWithPassword );
    [transKeyPad setKeyboardType:keyboardType maxLength:maxLength minLength:0];
    
    // 언어 설정
    [transKeyPad mTK_SetLanguage:mTK_Language_Korean];
    
    //하단 Safe Area 적용
    [transKeyPad mTK_SetBottomSafeArea:YES];
    
    // 취소 버튼 생성
    [transKeyPad mTK_DisableCancelBtn:NO];
    
    /*
     * 키패드노출 애니메이션
     */
//    [transKeyPad mTK_UseKeypadAnimation:YES];
    
    //라이선스 적용
    [transKeyPad mTK_LicenseCheck:@"license_mtranskey"];
//    int res = [transKeyPad mTK_LicenseCheck:@"license_mtranskey"];
//    NSLog(@"License Check Result : %d", res);
    
    self.m_usingTransKey = transKeyPad;
}

/*
 * 암호데이터 추출
 */
- (void)exportCipherString {
    NSString *cipherDataExString = [self.m_usingTransKey getCipherDataEx];
    NSString *pubKey = [[NSBundle mainBundle] pathForResource:@"Server2048" ofType:@"der"];
    NSString *_RSACipherPacketString = [self.m_usingTransKey mTK_EncryptSecureKey:pubKey cipherString:cipherDataExString];
    
    /*
     * RSA 암호문 보기
     */
    NSLog(@"RSA Cipher Packet : %@", _RSACipherPacketString);
    
    char plainData[256];
    NSData *qkey = [self.m_usingTransKey getSecureKey];
    
    /*
     * plane Text 보기
     */
    [self.m_usingTransKey getPlainDataExWithKey:qkey cipherString:cipherDataExString plainString:plainData length:256];
    NSString *originString = [[NSString alloc] initWithCString:plainData encoding:NSUTF8StringEncoding];
    NSLog(@"transkey decode : %@", originString);
    
    self.m_originText = originString;
    NSLog(@"Origin Text : %@", self.m_originText);

    if ( [_RSACipherPacketString validation] ) {
        self.m_cipherText = _RSACipherPacketString;
    }
}


/*
 * 보안키패드 삭제
 */
- (void)clean {
    if ( self.m_usingTransKey ) {
        [self.m_usingTransKey clear];
//        [self.m_usingTransKey mTK_ClearDelegateSubviews];
        [self.m_usingTransKey TranskeyResignFirstResponder];
        [self.m_usingTransKey removeFromSuperview];
        self.m_usingTransKey = nil;
    }
}

/*
 * 보안키패드 올리기
 */
- (void)showKeypad {
    if ( self.m_usingTransKey ) {
        [self.m_usingTransKey TranskeyBecomeFirstResponder];
        self.m_isShow = YES;
    }
}

/*
 * 보안키패드 내리기
 */
- (void)hideKeypad {
    if ( self.m_usingTransKey ) {
        [self.m_usingTransKey TranskeyResignFirstResponder];
        self.m_isShow = NO;
    }
}


#pragma mark - TransKeyDelegate
- (BOOL)TransKeyShouldReturn:(TransKey *)transKey {
    return YES;
}

- (BOOL)TransKeyShouldInternalReturn:(TransKey *)transKey btnType:(NSInteger)type{
    
    if(type == CompleteCmdType || type == NaviCompleteCmdType) {
        
        if ( [transKey mTK_GetInputLength] == 0 ) {
            [self hideKeypad];
            return YES;
        }
        
        /*
         * 암호데이터 추출
         */
        [self exportCipherString];
        
        /*
         * 키패드 내리기
         */
        [self hideKeypad];
        
        /*
         * 델리게이트 콜백
         */
        if ( [self.m_hcSecureTextFieldDelegate respondsToSelector:@selector(secureTransKeyShouldReturn)] ) {
            [self.m_hcSecureTextFieldDelegate secureTransKeyShouldReturn];
        }
    }
    else if ( type == CancelCmdType ) {
        
        self.m_cipherText = nil;
        [self setText:@""];
        
        /*
         * 캐피드 내리기
         */
        [self hideKeypad];
        
        /*
         * 데이터 초기화
         */
        [self resetTransKey];
        
        /*
         * 델리게이트 콜백
         */
        if ( [self.m_hcSecureTextFieldDelegate respondsToSelector:@selector(secureTransKeyCancelKeypad)] ) {
            [self.m_hcSecureTextFieldDelegate secureTransKeyCancelKeypad];
        }
        
        return NO;
    }
    
    return YES;
}

- (void)TransKeyInputKey:(NSInteger)keytype{
    if ( !self.m_dummyPasswordString ) {
        self.m_dummyPasswordString = [[NSMutableString alloc] init];
    }
    [self.m_dummyPasswordString setString:@""];
    
    NSInteger inputLength = [self.m_usingTransKey mTK_GetInputLength];
    for ( NSInteger i = 1; i <= inputLength; i++ ) {
        [self.m_dummyPasswordString appendString:@"*"];
    }
    [self setText:self.m_dummyPasswordString];
    
    
    /*
     * 암호화 데이터 추출
     */
    [self exportCipherString];
    
    /*
     * 텍스트필드에 넣어줄 특수문자 ( * )
     */
    
    if ( self.m_isShow ) {
        if ( [self.m_hcSecureTextFieldDelegate respondsToSelector:@selector(secureTransKeyInput)] ) {
            [self.m_hcSecureTextFieldDelegate secureTransKeyInput];
        }
    }
}

- (void)TransKeyDidBeginEditing:(TransKey *)transKey {
//    if ( [self.m_hcSecureTextFieldDelegate respondsToSelector:@selector(secureTransKeyBeginEditing:)] ) {
//        [self.m_hcSecureTextFieldDelegate secureTransKeyBeginEditing:self];
//    }
}

- (void)TransKeyDidEndEditing:(TransKey *)transKey {
//    if ( [self.m_hcSecureTextFieldDelegate respondsToSelector:@selector(secureTransKeyEndEditing:)] ) {
//        [self.m_hcSecureTextFieldDelegate secureTransKeyEndEditing:self];
//    }
}

- (void)TranskeyWillBeginEditing:(TransKey *)transKey {
    if ( [self.m_hcSecureTextFieldDelegate respondsToSelector:@selector(secureTransKeyBeginEditing)] ) {
        [self.m_hcSecureTextFieldDelegate secureTransKeyBeginEditing];
    }
}

- (void)TranskeyWillEndEditing:(TransKey *)transKey {
    if ( [self.m_hcSecureTextFieldDelegate respondsToSelector:@selector(secureTransKeyEndEditing)] ) {
        [self.m_hcSecureTextFieldDelegate secureTransKeyEndEditing];
    }
}



- (void)TransKeyEndCreating:(TransKey *)transKey{
    //키패드 생성 이후 호출
    if(transKey != nil){
//        [transKey mTK_SetCompleteBtnHide:YES]; //입력완료 버튼 감춤
        NSLog(@"KeyPad Height : %lf", [transKey mTK_GetCurrentKeypadHeight]);
        NSLog(@"KeyPad x : %lf", [transKey mTK_GetCurrentKeypadX]);
    }

    if ( [self.m_hcSecureTextFieldDelegate respondsToSelector:@selector(secureTransKeyDidEndCreating:)] ) {
        [self.m_hcSecureTextFieldDelegate secureTransKeyDidEndCreating:transKey];
    }
}


//콜백확인
//- (void)TransKeyMinLengthCallback:(TransKey *)transkey {
//    NSLog(@"TransKeyMinLengthCallback");
//}
//- (void)TransKeyMaxLengthCallback:(TransKey *)transkey {
//    NSLog(@"TransKeyMaxLengthCallback");
//}


@end
