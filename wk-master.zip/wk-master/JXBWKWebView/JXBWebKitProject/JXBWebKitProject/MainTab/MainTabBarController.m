

#import "MainTabBarController.h"

#import "InitViewController.h"
#import "MyAccountViewController.h"
#import "ServiceViewController.h"
#import "MoreViewController.h"
#import "AppDelegate.h"
#import "NSString+Addition.h"
#import "LoadingViewController.h"
#import "SharedData.h"
#import "HCAlertView.h"

@interface MainTabBarController () <MainTabBarViewDelegate>

@end

@implementation MainTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    [self configure];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    /*
    * 현재메인탭바가 아닌 클래스들은 전부삭제
    * 1. 회원가입에서 진입한경우
    * 2. 법인카드 등록 프로세스에서 취소한 경우
    * 3. 앱을 처음 구동한경우 InitViewController가 존재할 수 있음.
    */
    for ( UIViewController *vc in self.navigationController.viewControllers ) {
        if ( ![vc isKindOfClass:[self class]] ) {
            [vc removeFromParentViewController];
        }
    }
}

- (void)configure {
    
    id myaccount  = [CommonUtil storyboardName:@"MyAccount" identifier:nil];
    id service = [CommonUtil storyboardName:@"Service" identifier:nil];
    id more   = [CommonUtil storyboardName:@"More" identifier:nil];

    NSArray *array = [[NSArray alloc] initWithObjects:myaccount, service, more, nil];
    
    [self setViewControllers:array];
    
    [self createTabBar];
}

- (void)createTabBar {
    //탭바구성
    
    CGFloat tabBarHeight = [MainTabBarView tabBarHeight];
    CGFloat posY = self.view.bounds.size.height - ( tabBarHeight + [CommonUtil heightForBottomPadding] );
    
//    MainTabBarView *tabBarView = [CommonUtil loadNibNamed:@"MainTabBarView" className:@"MainTabBarView"];
//    tabBarView.m_mainTabBarViewDelegate = self;
//    [tabBarView setFrame:CGRectMake(0.0f, posY, self.view.bounds.size.width, tabBarHeight)];
//    [tabBarView defalutMainTapButton];
    
    self.m_mainTabBarView.m_mainTabBarViewDelegate = self;
    [self.m_mainTabBarView setFrame:CGRectMake(0.0f, posY, self.view.bounds.size.width, tabBarHeight)];
    [self.m_mainTabBarView defalutMainTapButton];
    
    [self.view addSubview:self.m_mainTabBarView];
    
    
//    tabBarView.layer.borderColor = [UIColor redColor].CGColor;
//    tabBarView.layer.borderWidth = 1.0f;
    
}

#pragma mark - MainTabBarViewDelegate
- (void)mainTabBarViewDidSelectedIndex:(NSInteger)tabIndex {
    self.selectedIndex = tabIndex;
}

- (void)popToClassRootViewController{
    UINavigationController *classNavController = (UINavigationController *)[self.viewControllers objectAtIndex:2];
    [classNavController popToRootViewControllerAnimated:false];
}

@end
