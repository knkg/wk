

#import <UIKit/UIKit.h>
#import "MainTabBarView.h"

NS_ASSUME_NONNULL_BEGIN

@interface MainTabBarController : UITabBarController 

@property (nonatomic, weak) IBOutlet MainTabBarView *m_mainTabBarView;

/*
 * 회원가입후 진입하였는지 체크
 */
@property (nonatomic, assign) BOOL m_isFromSignUp;

@end

NS_ASSUME_NONNULL_END
