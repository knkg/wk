

#import "MainTabBarView.h"
#import "UIView+Addition.h"
#import "HCAlertView.h"

@implementation MainTabBarView

- (instancetype)initWithFrame:(CGRect)frame {
    if ( self = [super initWithFrame:frame] ) {
        return self;
    }
    
    
    return nil;
}

+ (CGFloat)tabBarHeight {
    return 48.0f;
}

- (void)defalutMainTapButton {
    [self myAccountButtonClick:YES];
    [self.m_imageViewMyAccount setHighlighted:true];
    
    [self.m_imageViewMyAccount setHighlighted:true];
    [self.m_imageViewMore setHighlighted:false];

}

- (void)allButtonToDeSelected {
    [self.m_imageViewMyAccount setImage:[UIImage imageNamed:@"icon_24px_my_account"]];
    [self.m_imageViewSerivce setImage:[UIImage imageNamed:@"icon_24px_service"]];
    [self.m_imageViewMore setImage:[UIImage imageNamed:@"icon_24px_more"]];
}

- (void)myAccountButtonClick:(BOOL)isClick {
    [self allButtonToDeSelected];
    if ( isClick ) {
        [self.m_imageViewMyAccount setImage:[UIImage imageNamed:@"icon_24px_my_account_on"]];
        [self.m_imageViewMyAccount setHighlighted:YES];
    }
    [self.m_imageViewMyAccount setHighlighted:true];
    [self.m_imageViewMore setHighlighted:false];

}

- (void)serviceButtonClick:(BOOL)isClick {
//    [self allButtonToDeSelected];
//    if ( isClick ) {
//        [self.m_imageViewSerivce setImage:[UIImage imageNamed:@"icon_24px_service_on"]];
//    }
    
//    if([self.m_imageViewMyAccount getImage:[UIImage imageNamed:@"icon_24px_my_account"]];
//    [self.m_imageViewSerivce setImage:[UIImage imageNamed:@"icon_24px_service"]];
//    [self.m_imageViewMore setImage:[UIImage imageNamed:@"icon_24px_more"]];

    NSLog(@" knkg tab value0=%d", self.m_imageViewMyAccount.isHighlighted);
    NSLog(@" knkg tab value1=%d", self.m_imageViewMore.isHighlighted);
    
          NSString *str = @"서비스준비중입니다.";
          [HCAlertView alertWithTtile:@"알림" message:str confirmButtonTitle:@"확인" cancelButtontitle:nil completion:^(BOOL confirm) {
              
              if(self.m_imageViewMyAccount.isHighlighted == 1){
                  NSLog(@"goto account");
                  [self myAccountButtonClick:YES];
                  if ( [self.m_mainTabBarViewDelegate respondsToSelector:@selector(mainTabBarViewDidSelectedIndex:)] ) {
                      [self.m_mainTabBarViewDelegate mainTabBarViewDidSelectedIndex:0];
                  }
              }else if(self.m_imageViewMore.isHighlighted == 1){
                  NSLog(@"goto more");
                  [self moreButtonClick:YES];
                  if ( [self.m_mainTabBarViewDelegate respondsToSelector:@selector(mainTabBarViewDidSelectedIndex:)] ) {
                      [self.m_mainTabBarViewDelegate mainTabBarViewDidSelectedIndex:2];
                  }
              }
           }
          ];
     
}

- (void)moreButtonClick:(BOOL)isClick {
    [self allButtonToDeSelected];
    if ( isClick ) {
        [self.m_imageViewMore setImage:[UIImage imageNamed:@"icon_24px_more_on"]];
    }
    [self.m_imageViewMyAccount setHighlighted:false];
    [self.m_imageViewMore setHighlighted:true];

}

- (IBAction)butonTouchedMyAccount:(UIButton *)sender {
    NSLog(@"butonTouchedMyAccount");
    [self.m_mainTabBarViewDelegate popToClassRootViewController];
    [self myAccountButtonClick:YES];
    if ( [self.m_mainTabBarViewDelegate respondsToSelector:@selector(mainTabBarViewDidSelectedIndex:)] ) {
        [self.m_mainTabBarViewDelegate mainTabBarViewDidSelectedIndex:0];
    }
}

- (IBAction)butonTouchedSerivce:(UIButton *)sender {
    NSLog(@"butonTouchedSerivce");
    [self.m_mainTabBarViewDelegate popToClassRootViewController];
    [self serviceButtonClick:YES];
    if ( [self.m_mainTabBarViewDelegate respondsToSelector:@selector(mainTabBarViewDidSelectedIndex:)] ) {
        [self.m_mainTabBarViewDelegate mainTabBarViewDidSelectedIndex:1];
    }
}

- (IBAction)butonTouchedMore:(UIButton *)sender {
    NSLog(@"butonTouchedMore");
    [self.m_mainTabBarViewDelegate popToClassRootViewController];
    [self moreButtonClick:YES];
    if ( [self.m_mainTabBarViewDelegate respondsToSelector:@selector(mainTabBarViewDidSelectedIndex:)] ) {
        [self.m_mainTabBarViewDelegate mainTabBarViewDidSelectedIndex:2];
    }
}

@end
