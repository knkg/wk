

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol MainTabBarViewDelegate <NSObject>

@required
- (void)mainTabBarViewDidSelectedIndex:(NSInteger)tabIndex;
- (void)popToClassRootViewController;
@end


@interface MainTabBarView : UIView

@property (nonatomic, weak) id<MainTabBarViewDelegate> m_mainTabBarViewDelegate;

@property (nonatomic, weak) IBOutlet UIView *m_viewMyAccount;
@property (nonatomic, weak) IBOutlet UIView *m_viewService;
@property (nonatomic, weak) IBOutlet UIView *m_viewMore;

@property (nonatomic, weak) IBOutlet UIImageView *m_imageViewMyAccount;
@property (nonatomic, weak) IBOutlet UIImageView *m_imageViewSerivce;
@property (nonatomic, weak) IBOutlet UIImageView *m_imageViewMore;

@property (nonatomic, weak) IBOutlet UILabel *m_lbMyAccount;
@property (nonatomic, weak) IBOutlet UILabel *m_lbSerivce;
@property (nonatomic, weak) IBOutlet UILabel *m_lbMore;

@property (nonatomic, weak) IBOutlet UIButton *m_btnMyAccount;
@property (nonatomic, weak) IBOutlet UIButton *m_btnSerivce;
@property (nonatomic, weak) IBOutlet UIButton *m_btnMore;


- (void)defalutMainTapButton;
+ (CGFloat)tabBarHeight;

@end

NS_ASSUME_NONNULL_END
