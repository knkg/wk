

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^CustomAlertViewBlock)(BOOL confrim);

@interface CustomAlertView : UIView

@property (nonatomic, weak) IBOutlet UIView *viewMessageBox;

@property (nonatomic, weak) IBOutlet UILabel *lbTitle;
@property (nonatomic, weak) IBOutlet UILabel *lbMessage;

@property (nonatomic, weak) IBOutlet UIView *viewBottom;

@property (nonatomic, weak) IBOutlet UIButton *btnConform;
@property (nonatomic, weak) IBOutlet UIButton *btnCancel;


- (void)alertWithTitlt:(nullable NSString *)title
               message:(NSString *)message
    buttonTitleConfrim:(NSString *)titleConfirm
     buttonTitleCancel:(nullable NSString *)titleCancel
            completion:(nullable CustomAlertViewBlock)completion;
    
@end

NS_ASSUME_NONNULL_END
