

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void  (^OnCompletionAlertConfirm)(BOOL confirm);

@interface HCAlertView : NSObject


+ (void)alertWithMessage:(NSString *)message
      confirmButtonTitle:(NSString *)confrimTitle
       cancelButtontitle:(nullable NSString *)cancelTitle
              completion:(nullable OnCompletionAlertConfirm)completion;

+ (void)alertWithTtile:(NSString *)title
               message:(NSString *)message
    confirmButtonTitle:(NSString *)confrimTitle
     cancelButtontitle:(nullable NSString *)cancelTitle
            completion:(nullable OnCompletionAlertConfirm)completion;
@end

NS_ASSUME_NONNULL_END
