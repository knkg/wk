

#import "CustomAlertView.h"
#import "NSString+Addition.h"
#import "AppDelegate.h"

@interface CustomAlertView()

@property (nonatomic, assign) BOOL m_isTitle;

@property (nonatomic, copy) CustomAlertViewBlock m_completion;


@end

@implementation CustomAlertView

- (void)drawRect:(CGRect)rect {
    
}

//- (void)alertWithTitlt:(NSString *)title message:(NSString *)message buttonTitleConfrim:(NSString *)titleConfirm buttonTitleCancel:(nullable NSString *)titleCancel completion:(nullable CustomAlertViewBlock)completion {
//    self.m_completion = completion;
//
//    __weak typeof(self) weakSelf = self;
//    dispatch_async(dispatch_get_main_queue(), ^{
//        __strong typeof(weakSelf) strongSelf = weakSelf;
//
//        CGRect rect = CGRectZero;
//
//        //제목이 있는 알림창인 경우.
//        if ( [title validation] ) {
//            strongSelf.m_isTitle = YES;
//            [strongSelf.lbTitle setText:title];
//
//            rect = strongSelf.lbTitle.frame;
//            rect.size.width = strongSelf.viewMessageBox.bounds.size.width - 60.0f;
//            strongSelf.lbTitle.frame = rect;
//
////            [strongSelf.lbTitle sizeToFit];
//        }
//        else {
//            [strongSelf.lbTitle setHidden:YES];
//        }
//
//        [strongSelf.lbMessage setText:message];
//        [strongSelf.lbMessage sizeToFit];
//
//        strongSelf.lbTitle.layer.borderColor = [UIColor redColor].CGColor;
//        strongSelf.lbTitle.layer.borderWidth = 1.0f;
//
//        strongSelf.lbMessage.layer.borderColor = [UIColor redColor].CGColor;
//        strongSelf.lbMessage.layer.borderWidth = 1.0f;
//
//        //취소버튼이 없는 알림창인 경우.
//        if ( ![titleCancel validation] ) {
//            [strongSelf.btnCancel setHidden:YES];
//            [strongSelf.lbBtnCancel setHidden:YES];
//        }
//
//        //뷰객체 포지션 조정
//        [strongSelf updateUI];
//
//        //알림창 보여기
//        [[[UIApplication sharedApplication] delegate].window addSubview:self];
//
//    });
//}

- (void)alertWithTitlt:(NSString *)title message:(NSString *)message buttonTitleConfrim:(NSString *)titleConfirm buttonTitleCancel:(nullable NSString *)titleCancel completion:(nullable CustomAlertViewBlock)completion {
    self.m_completion = completion;
    
    //제목이 있는 알림창인 경우.
    if ( title.length > 0 ) {
        self.m_isTitle = YES;
        [self.lbTitle setText:title];
        //[self.lbTitle sizeToFit];
    }
    else {
        [self.lbTitle setHidden:YES];
    }
    
    [self.lbMessage setText:message];
    [self.lbMessage sizeToFit];
    [self.lbMessage setTextAlignment:NSTextAlignmentCenter];
    
    if ( [titleConfirm validation] ) {
        [self.btnConform setTitle:titleConfirm forState:UIControlStateNormal];
    }
    
    if ( [titleCancel validation] ) {
        [self.btnCancel setTitle:titleCancel forState:UIControlStateNormal];
    }
    
    
//    self.lbTitle.layer.borderColor = [UIColor redColor].CGColor;
//    self.lbTitle.layer.borderWidth = 1.0f;
//
//    self.lbMessage.layer.borderColor = [UIColor redColor].CGColor;
//    self.lbMessage.layer.borderWidth = 1.0f;
    
    //취소버튼이 없는 알림창인 경우.
    if ( ![titleCancel validation] ) {
        [self.btnCancel setHidden:YES];
//        [self.lbBtnCancel setHidden:YES];
    }
    
    //뷰객체 포지션 조정
    [self updateUI];
    
    //알림창 보여기
    [[[UIApplication sharedApplication] delegate].window addSubview:self];
    

}

- (void)updateUI {
    
    self.frame = [UIScreen mainScreen].bounds;
    [self.viewMessageBox.layer setCornerRadius:18.0f];
    [self.viewMessageBox.layer setMasksToBounds:YES];
    
    CGRect rect = CGRectZero;
    
    //제목이 없으면 내용을 제목위치로 이동.
    if ( !self.m_isTitle ) {
        rect = self.lbMessage.frame;
        rect.origin.y = self.lbTitle.frame.origin.y;
        self.lbMessage.frame = rect;
    }
    //제목이 있으면 메시지를 제목 아래 20포인트 공백을 줌
    else {
        rect = self.lbMessage.frame;
        rect.origin.y = CGRectGetMaxY(self.lbTitle.frame) + 20.0f;
        self.lbMessage.frame = rect;
    }
    
    //하단버튼뷰 'Y'좌표 조정
    rect = self.viewBottom.frame;
    rect.origin.y = CGRectGetMaxY(self.lbMessage.frame) + 25.0f;
    self.viewBottom.frame = rect;
    
    //확인버튼 하나만 존재할 경우 ( 알림창이 원버튼 일경우 )
    if ( self.btnCancel.hidden ) {
        //라벨 늘리기
        rect = self.btnConform.frame;
        rect.origin.x = 0.0f;
        rect.size.width = self.viewBottom.bounds.size.width;
        self.btnConform.frame = rect;
        
        //버튼을 라벨과 동일하게 변경
//        self.btnConform.frame = self.lbBtnConfirm.frame;
    }
    
    //전체메시지 박스 크기조정
    rect = self.viewMessageBox.frame;
    rect.size.height = CGRectGetMaxY(self.viewBottom.frame);
    self.viewMessageBox.frame = rect;
    
    //메시지 박스 센터 정렬
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    [self.viewMessageBox setCenter:CGPointMake(screenSize.width/2.0f, screenSize.height/2.0f)];
    
 
    
    
}

#pragma mark - button event
- (IBAction)buttonTouchedToConfirm:(id)sender {
    if ( self.m_completion ) {
        self.m_completion(YES);
    }
}


- (IBAction)buttonTouchedToCancel:(id)sender {
    if ( self.m_completion ) {
        self.m_completion(NO);
    }
}




@end
