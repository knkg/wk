

#import "HCAlertView.h"
#import "CustomAlertView.h"
#import "NSString+Addition.h"

@interface HCAlertView()

@property (nonatomic, strong) CustomAlertView *m_customAlertView;

@end

@implementation HCAlertView

+ (instancetype)sharedInstance {
    static HCAlertView *instance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    
    return instance;
}

- (instancetype)init {
    if ( self = [super init] ) {
        return self;
    }
    
    return nil;
}

#pragma mark - AlertView
- (CustomAlertView *)getAlertView {
    [self closeAlert];
    self.m_customAlertView = (CustomAlertView *) [[[NSBundle mainBundle] loadNibNamed:@"CustomAlertView" owner:nil options:nil] lastObject];

    CGRect frame = [UIScreen mainScreen].bounds;
    [self.m_customAlertView setFrame:frame];
    return self.m_customAlertView;
}

- (void)closeAlert {
    if ( self.m_customAlertView ) {
        [self.m_customAlertView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
        [self.m_customAlertView removeFromSuperview];
        self.m_customAlertView = nil;
    }
}


+ (void)alertWithMessage:(NSString *)message confirmButtonTitle:(NSString *)confrimTitle cancelButtontitle:(nullable NSString *)cancelTitle completion:(OnCompletionAlertConfirm)completion {
    
    HCAlertView *alertView = [HCAlertView sharedInstance];
    [[alertView getAlertView] alertWithTitlt:nil
                                message:message
                     buttonTitleConfrim:confrimTitle
                      buttonTitleCancel:cancelTitle
                             completion:^(BOOL confrim) {
                                 [alertView closeAlert];
                                 
                                 if ( completion ) {
                                     completion(confrim);
                                 }
                                 
                             }];
}

+ (void)alertWithTtile:(NSString *)title message:(NSString *)message confirmButtonTitle:(NSString *)confrimTitle cancelButtontitle:(nullable NSString *)cancelTitle completion:(OnCompletionAlertConfirm)completion {
    
    HCAlertView *alertView = [HCAlertView sharedInstance];

    [[alertView getAlertView] alertWithTitlt:title
                                message:message
                     buttonTitleConfrim:confrimTitle
                      buttonTitleCancel:cancelTitle
                             completion:^(BOOL confrim) {
                                 [alertView closeAlert];
                                 
                                 if ( completion ) {
                                     completion(confrim);
                                 }
                                 
                             }];
}

@end
