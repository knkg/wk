

typedef void (^OnForegroundHandler)(void);
typedef void (^OnBackgroundHandler)(void);

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BackgroundTaskManager : NSObject

+ (instancetype) sharedInstance;

/*
 * 앱이 실행중일대 받는 콜백핸들러
 */
- (void)actionForForgroundServiceHandler:(nonnull OnForegroundHandler)handler;

/*
 * 앱이 백그라운드로 실행중일때 받는 콜백핸들러
 */
- (void)actionForBackgroundServiceHandler:(nonnull OnBackgroundHandler)handler;

/*
 * 노티피케이션 등록
 */
- (void)addNotification;

/*
 * 노티피케이션 삭제
 */
- (void)removeNotification;


/*
 * 앱이 실행중일때 타이머로 호출되는 함수
 */
- (void)applicationDidBecomeActive;

/*
 * 앱이 백그라운드 상태일때 타이머로 호출되는 함수
 */
- (void)applicationDidEnterBackground;

/*
 * UIBackgroundTask 등록
 */
- (void)registBackgroundTask;

/*
 * UIBackgroundTask 해제
 */
- (void)endBackgroundTask;

/*
 * 백그라운드 종료
 */
- (void)finishBackgroundTask;

/*
 * 타임아웃 플래그 'YES' 처리
 */
- (void)timeExpire;

/*
 * 타임아웃 플래스 초기화
 */
- (void)resetTimeExpire;

@end

NS_ASSUME_NONNULL_END

