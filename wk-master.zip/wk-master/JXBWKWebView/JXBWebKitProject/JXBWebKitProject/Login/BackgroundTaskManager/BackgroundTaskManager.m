
#import "BackgroundTaskManager.h"


@interface BackgroundTaskManager()

@property (nonatomic, assign) UIBackgroundTaskIdentifier m_backgroundTask;
@property (nonatomic, strong) NSTimer *m_timer;

@property (nonatomic, copy) OnForegroundHandler m_onForegroundHandler;
@property (nonatomic, copy) OnBackgroundHandler m_onBackgroundHandler;

@property (nonatomic, assign) BOOL isFinish;


@end

@implementation BackgroundTaskManager

+ (instancetype) sharedInstance {
    static BackgroundTaskManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if(instance == nil) {
            instance = [[self alloc] init];
        }
    });
    
    return instance;
}

/*
 * 콜백받을 시간간격
 */
- (NSTimeInterval)timeInterval {
    return 5;
}


/*
 * 앱이 실행중일대 받는 콜백핸들러
 */
- (void)actionForForgroundServiceHandler:(nonnull OnForegroundHandler)handler {
    self.m_onForegroundHandler = handler;
}

/*
 * 앱이 백그라운드로 실행중일때 받는 콜백핸들러
 */
- (void)actionForBackgroundServiceHandler:(nonnull OnBackgroundHandler)handler {
    self.m_onBackgroundHandler = handler;
}

/*
 * 노티피케이션 등록
 */
- (void)addNotification {
    
    /*
     * 등록되었던 노티피케이션 삭제
     */
    [self removeNotification];
    
    /*
     * Foreground 노티피케이션 등록
     */
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive) name:UIApplicationDidBecomeActiveNotification object:nil];
    
    /*
     * Background 노티피케이션 등록
     */
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidEnterBackground) name:UIApplicationDidEnterBackgroundNotification object:nil];
}

/*
 * 노티피케이션 삭제
 */
- (void)removeNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


/*
 * 앱이 실행중일때 타이머로 호출되는 함수
 */
- (void)applicationDidBecomeActive {
    [self endBackgroundTask];
    if ( self.m_onForegroundHandler ) {
        self.m_onForegroundHandler();
    }
    
    /*
     * 타이아웃 플래그 초기화
     */
    [self resetTimeExpire];
    
    /*
     * 백그라운드 종료
     */
    [self finishBackgroundTask];
}

/*
 * 앱이 백그라운드 상태일때 타이머로 호출되는 함수
 */
- (void)applicationDidEnterBackground {
    
    /*
     * 타임아웃으로 더이상 백그라운드프로그램을 실행하지 않을경우
     */
    if ( self.isFinish ) {
        NSLog(@"백그라운드 종료");
        
        /*
         * 백그라운드 종료
         */
        [self finishBackgroundTask];
        
        return;
    }
    
    /*
    * 타이아웃 플래그 초기화
    */
    [self resetTimeExpire];
    
    /*
     * 백그라운드 task 등록
     */
    [self registBackgroundTask];
    
    if ( self.m_timer ) {
        if ( self.m_onBackgroundHandler ) {
            self.m_onBackgroundHandler();
        }
    }
    
    /*
     * 타이머 등록
     */
    [self.m_timer invalidate];
    self.m_timer = nil;
    self.m_timer = [NSTimer scheduledTimerWithTimeInterval:[self timeInterval] target:self selector:@selector(applicationDidEnterBackground) userInfo:nil repeats:NO];
}

/*
 * UIBackgroundTask 등록
 */
- (void)registBackgroundTask {
    __weak typeof(self) weakSelf = self;
    self.m_backgroundTask = [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        __weak typeof(weakSelf) strongSelf = self;
        [strongSelf endBackgroundTask];
    }];
  
}

/*
 * UIBackgroundTask 해제
 */
- (void)endBackgroundTask {
    if ( self.m_backgroundTask != UIBackgroundTaskInvalid ) {
        [[UIApplication sharedApplication] endBackgroundTask:self.m_backgroundTask];
        self.m_backgroundTask = UIBackgroundTaskInvalid;
    }
}

/*
 * 백그라운드 종료
 */
- (void)finishBackgroundTask {
    [self endBackgroundTask];
//    [self removeNotification];
    [self.m_timer invalidate];
    self.m_timer = nil;
}

/*
 * 타임아웃 플래그 'YES' 처리
 */
- (void)timeExpire {
    self.isFinish = YES;
}

/*
 * 타임아웃 플래스 초기화
 */
- (void)resetTimeExpire {
    self.isFinish = NO;
}

@end

