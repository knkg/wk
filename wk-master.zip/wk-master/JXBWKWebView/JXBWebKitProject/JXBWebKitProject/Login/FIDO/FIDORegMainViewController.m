

#import "FIDORegMainViewController.h"
#import "FIDOController.h"
#import "HCAlertView.h"
#import "SharedData.h"
#import "FileUtil.h"
#import "FIDOController.h"


@interface FIDORegMainViewController ()

@end

@implementation FIDORegMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self.m_btnSetting.layer setCornerRadius:8.0f];
    [self.m_btnSetting.layer setMasksToBounds:YES];
    
    [self.m_btnCancel.layer setCornerRadius:8.0f];
    [self.m_btnCancel.layer setMasksToBounds:YES];
    
    
    /*
     * 터치아이디, 페이스아이디 구분
     */
//    if ( [CommonUtil heightForBottomPadding] <= 0.0f ) {
//        [self.m_imvBioAuth setImage:[UIImage imageNamed:@"fido_s_fingerprint_blue"]];
//    }
    
//    [self.m_viewBioAuthBG.layer setCornerRadius:self.m_viewBioAuthBG.bounds.size.width/2.0f];
//    [self.m_viewBioAuthBG.layer setMasksToBounds:YES];
    
}


#pragma mark - Costom Mehtod

- (BOOL)isSignUpProcess {
   
    BOOL isFind = NO;
    for ( id vc in self.navigationController.viewControllers ) {
        if ( [vc isKindOfClass:NSClassFromString(@"SignUpSelectCompanyViewController")] ) {
            isFind = YES;
            break;
        }
    }
    
    return isFind;
}

- (void)successInfo:(id)info {
    
    __weak typeof(self) weakSelf = self;
    
    NSString *title = @"FaceID 인증 설정 완료";
    NSString *message = @"FaceID가 설정되었습니다.\nFaceID 설정 변경은 전체메뉴 > 설정 > Face ID 관리에서 가능합니다.";
    
    /*
     * 아이폰 10 미만폰인 경우
     */
    if ( [CommonUtil heightForBottomPadding] <= 0 ) {
        title = [title stringByReplacingOccurrencesOfString:@"FaceID" withString:@"TouchID"];
        message = [title stringByReplacingOccurrencesOfString:@"FaceID" withString:@"TouchID"];
    }
    
 
    
    [HCAlertView alertWithTtile:title message:message confirmButtonTitle:@"확인" cancelButtontitle:nil completion:^(BOOL confirm) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        
        /*
         * 현재 회원가입 단계라면 가입완료페이지로 이동
         */
        if ( [strongSelf isSignUpProcess] ) {
            id vc = [CommonUtil storyboardName:@"SignUpPasswrdSetting" identifier:@"SignUpCompleteViewController"];
            [strongSelf.navigationController pushViewController:vc animated:YES];
        }
        else {
            
            [self.navigationController popViewControllerAnimated:YES];
            
//            [strongSelf dismissViewControllerAnimated:YES completion:^{
//                if ( [strongSelf.m_FIDORegMainViewControllerDelegate respondsToSelector:@selector(fidoRegCompletionResult:)] ) {
//                    [strongSelf.m_FIDORegMainViewControllerDelegate fidoRegCompletionResult:info];
//                }
//            }];
        }
        
    }];
}

//#pragma mark - FIDOControllerDelegate
///*
// * 파이도 등록이 성공했을때만 넘어옴.
// */
//- (void)fidoReceivedMessage:(NSDictionary *)info {
//    [FileUtil saveObject:@"Y" forKey:CONST_KEY_FIDO_USE_YN];
//    
//    /*
//     * 앱서버간에 여러번 주고받아야 함.
//     * 현재 인터넷이 안되는 환경이기 때문에 여기까지 밖에 못함.
//     */
//    [self successInfo:info];
//}

#pragma mark - IBAction

- (IBAction)buttonTouchedSetting:(id)sender {
    
    __weak typeof(self) weakSelf = self;
    [[FIDOController sharedInstance] fidoRegistWithDelegate:nil completion:^(BOOL success, NSDictionary * _Nullable result) {
        if ( success ) {
            __weak typeof(weakSelf) strongSelf = weakSelf;

            [FileUtil saveObject:@"Y" forKey:CONST_KEY_FIDO_USE_YN];
            [FileUtil saveObject:LOGIN_TYPE_FIDO_AUTH forKey:CONST_KEY_LOGIN_TYPE];
            
            /*
             * 앱서버간에 여러번 주고받아야 함.
             * 현재 인터넷이 안되는 환경이기 때문에 여기까지 밖에 못함.
             */
            [strongSelf successInfo:result];
        }
    }];
}

- (IBAction)buttonTouchedCancel:(id)sender {
    /*
     * 현재 회원가입 단계라면 가입완료페이지로 이동
     */
    if ( [self isSignUpProcess] ) {
        id vc = [CommonUtil storyboardName:@"SignUpPasswrdSetting" identifier:@"SignUpCompleteViewController"];
        [self.navigationController pushViewController:vc animated:YES];
    }
    /*
     * 회원가입 단계가 아니라면
     */
    else {
//        if ( [self.m_FIDORegMainViewControllerDelegate respondsToSelector:@selector(fidoRegCancel)] ) {
//            [self.m_FIDORegMainViewControllerDelegate fidoRegCancel];
//        }
        
        /*
         * 이전페이지로...
         */
        [self.navigationController popViewControllerAnimated:YES];
    }
}


@end
