

#import "BaseViewController.h"
#import "FIDOController.h"

NS_ASSUME_NONNULL_BEGIN

//@protocol FIDORegMainViewControllerDelegate  <NSObject>
//
//@required
//- (void)fidoRegCompletionResult:(nullable id)result;
//- (void)fidoRegCancel;
//
//@end

@interface FIDORegMainViewController : BaseViewController

//@property (nonatomic, weak) id<FIDORegMainViewControllerDelegate> m_FIDORegMainViewControllerDelegate;

@property (nonatomic, weak) IBOutlet UIButton *m_btnSetting;
@property (nonatomic, weak) IBOutlet UIButton *m_btnCancel;
@property (nonatomic, weak) IBOutlet UIImageView* bioImageView;
//@property (nonatomic, weak) IBOutlet UIView *m_viewBioAuthBG;
//@property (nonatomic, weak) IBOutlet UIImageView *m_imvBioAuth;

@end

NS_ASSUME_NONNULL_END
