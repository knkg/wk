//
//  H5EnterModel.m
//  JXBWebKitProject
//
//  Created by 金修博 on 2018/8/3.
//  Copyright © 2018年 金修博. All rights reserved.
//

#import "H5EnterModel.h"

@implementation H5EnterModel

@end
