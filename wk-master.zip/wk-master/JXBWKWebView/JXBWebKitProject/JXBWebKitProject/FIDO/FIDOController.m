

#import "FIDOController.h"
#import "HCAlertView.h"
#import "NSString+Addition.h"
#import "LoadingViewController.h"
#import "HCAlertView.h"
#import "DeviceUtil.h"
#import "LoginController.h"
#import "NSString+Addition.h"
#import "FileUtil.h"
#import "AESUtil.h"
#import "SharedData.h"

#define FIDO_SUCCESS_CODE @"000"
#define FIDO_SUCCESS_MSG @"success"


#define ERROR_WRAPKEY_CD @"-16"
#define ERROR_WRAPKEY_MSG @"지문 추가,삭제 등 인증 정보가 변경되었습니다.\n생체인증 재등록 사용가능 합니다."



@interface FIDOController()

@property (nonatomic, copy) NSString *m_svcTrId;

@property (nonatomic, weak) id<FIDOControllerDelegate> m_fidoControllerDelegate;

@property (nonatomic, copy) completionFidoBlock m_completion;


@end

@implementation FIDOController

+ (instancetype)sharedInstance {
    static FIDOController *instance = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    
    return instance;
}

- (instancetype)init {
    if ( self = [super init] ) {
        return self;
    }
    
    return nil;
}


+ (BOOL)fidoLoginType {
    NSString *loginType = [FileUtil getObjectForKey:CONST_KEY_LOGIN_TYPE];
    if ( [loginType isEqualToString:LOGIN_TYPE_FIDO_AUTH] ) {
        return YES;
    }
    return NO;
}

+ (BOOL)fidoUseYn {
    
    NSString *fidoUseYn = [FileUtil getObjectForKey:CONST_KEY_FIDO_USE_YN];
    if ( [fidoUseYn isEqualToString:@"Y"] ) {
        return YES;
    }
    
    return NO;
}


/*
 * FIDO 사용가능 단말인지 체크
 */
+ (NSInteger)fidoCheckDevice {

    /*
     * 0 : 사용가능
     * ERROR_FAIL_FIND_DEVICE_TYPE : 생체인증 장치를 찾을 수 없습니다.
     * ERROR_NOT_SET_PASSCODE : OS 잠금설정이 되어 있지 않습니다.\n단말기 설정에서 암호 켜기 설정을 해주세요.
     * ERROR_TOUCHID_CAN_NOT_AVAILABLE : 생체인증을 사용할 수 없는 단말기 입니다. ( ERROR_NOT_SET_PASSCODE, ERROR_TOUCHID_NOT_ENROLLED 상태는 아님 )
     * ERROR_TOUCHID_NOT_ENROLLED : 생체인증이 등록되어 있지 않습니다.\n단말기 설정에서 생체인증을 등록해 주세요.
     */
    
    NSInteger resultCode = [OnePassUtil canUseFingerPrintAuthenticator];
    return resultCode;
}

+ (BOOL)canDevice {
    
    /*
     * 생체인증 지원단말 체크
     */
    BOOL canDevice = YES; //지원단말
    NSInteger errorCode = [FIDOController fidoCheckDevice];
    if ( errorCode == ERROR_FAIL_FIND_DEVICE_TYPE || errorCode == ERROR_TOUCHID_CAN_NOT_AVAILABLE ) {
        canDevice = NO;
    }
    
    return canDevice;
}

+ (BOOL)isSetPasscode {
    
    /*
     * OS 잠금설정 체크
     */
    BOOL isOSLock = YES; //잠금설정 상태
    NSInteger errorCode = [FIDOController fidoCheckDevice];
    if ( errorCode == ERROR_NOT_SET_PASSCODE ) {
        isOSLock = NO;
    }
    
    return isOSLock;
}

+ (BOOL)isEnrolledAuth {
    /*
     * 생체인증이 기등록 체크
     */
    BOOL isEnrolled = YES; //생체인증 기등록
    NSInteger errorCode = [FIDOController fidoCheckDevice];
    if ( errorCode == ERROR_TOUCHID_NOT_ENROLLED ) {
        isEnrolled = NO;
    }
    
    return isEnrolled;
}

+ (BOOL)canFIDO {
    if ( [FIDOController isSetPasscode] ) {
        if ( [FIDOController canDevice] ) {
            if ( [FIDOController isEnrolledAuth] ) {
                return YES;
            }
        }
    }
    
    return NO;
}


+ (BOOL)canDeviceMessage {
    
    /*
     * 생체인증 지원단말 체크
     */
    BOOL canDevice = YES; //지원단말
    NSInteger errorCode = [FIDOController fidoCheckDevice];
    if ( errorCode == ERROR_FAIL_FIND_DEVICE_TYPE || errorCode == ERROR_TOUCHID_CAN_NOT_AVAILABLE ) {
        [FIDOController fidoErrorMessage:@"생체인증을 지원하는 단말기가 아닙니다.\n단말기 상태를 확인해 주세요."];
        
        canDevice = NO;
    }
    
    return canDevice;
}

+ (BOOL)isSetPasscodeMessage {
    
    /*
     * OS 잠금설정 체크
     */
    BOOL isOSLock = YES; //잠금설정 상태
    NSInteger errorCode = [FIDOController fidoCheckDevice];
    if ( errorCode == ERROR_NOT_SET_PASSCODE ) {
        [FIDOController fidoErrorMessage:@"Passcode(OS 잠금비밀번호)가 등록되어 있지 않습니다.\nOS설정에서 Passcode(OS 잠금비밀번호)를 등록해 주세요."];
        isOSLock = NO;
    }
    
    return isOSLock;
}

+ (BOOL)isEnrolledAuthMessage {
    /*
     * 생체인증이 기등록 체크
     */
    BOOL isEnrolled = YES; //생체인증 기등록
    NSInteger errorCode = [FIDOController fidoCheckDevice];
    if ( errorCode == ERROR_TOUCHID_NOT_ENROLLED ) {
        [FIDOController fidoErrorMessage:@"현재 단말기에 등록된 생체인증정보를 찾을 수 없습니다.\nOS설정에서 생체인증정보를 등록해 주세요. "];
        isEnrolled = NO;
    }
    
    return isEnrolled;
}

+ (BOOL)canFIDOMessage {
    if ( [FIDOController canDeviceMessage] ) {
        if ( [FIDOController isSetPasscodeMessage] ) {
            if ( [FIDOController isEnrolledAuthMessage] ) {
                return YES;
            }
        }
    }
    
    return NO;
}

+ (void)errorMessage:(NSString *)message {
    [HCAlertView alertWithTtile:@"생체인증 사용 실패" message:message confirmButtonTitle:@"확인" cancelButtontitle:nil completion:nil];
}


- (void)initilaize {
    OnePassManager *manager = [OnePassManager sharedSingleton];
    [manager setInitInfo:CONST_FIDO_SERVER_URL
                  siteId:CONST_FIDO_SITE_ID
               serviceId:CONST_FIDO_SVC_ID
                  userId:@""
                delegate:self];
    
}

- (NSMutableDictionary *)defaultDataWithCommand:(NSString *)command {
    OnePassManager *manager = [OnePassManager sharedSingleton];

    NSString *deviceId = [manager getDeviceIdOnePass];
    NSString *appId = [manager facetId];  //@"android:apk-key-hash:Df+2X53ZOUscvUu6obxC3rifFyk";
    
    NSMutableDictionary *info = [[NSMutableDictionary alloc] init];
    [info setObject:command forKey:@"command"];
    [info setObject:[LoginController getUserId] forKey:@"loginId"];
    [info setObject:deviceId forKey:@"deviceId"];
    [info setObject:appId forKey:@"appId"];

    
    return info;
}

/*
 * FIDO 등록
 */
- (void)fidoRegistWithDelegate:(id<FIDOControllerDelegate>)delegate completion:(completionFidoBlock)completion {
    self.m_completion = completion;
    
    if ( ![FIDOController canFIDOMessage] ) {
        return;
    }
    
    NSLog(@"start fidoRegistWithDelegate");
    
    __weak typeof(self) weakSelf = self;

    self.m_fidoControllerDelegate = delegate;
    
    //rtoken 추가
    NSMutableDictionary *info = [self defaultDataWithCommand:@"requestServiceRegist"];
    NSString *encToken = [FileUtil getObjectForKey:CONST_KEY_AUTO_LOGIN_TOKEN];
    NSString *decToken = [AESUtil toDecryptWithString:encToken];
    [info setValue:decToken forKey:@"rtoken"];
    
    
    [NetAPIClient requestFidoAPI:CONST_URL_FIDO_TR_ID parameters:info successBlock:^(id  _Nullable result) {
        __strong typeof(weakSelf) strongSelf = weakSelf;

        NSData *data = [result dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        NSLog(@"[1]success fidoRegistWithDelegate : %@", dict);
        
        NSString *resultCode = [dict objectForKey:@"resultCode"];
        if ( [resultCode isEqualToString:FIDO_SUCCESS_CODE] ) {
            NSString *trId = [[dict objectForKey:@"resultData"] objectForKey:@"trId"];

            NSString *svcTrId = [dict objectForKey:@"svcTrId"];
            strongSelf.m_svcTrId = svcTrId;
            
            NSLog(@"[2]success fidoRegistWithDelegate trId : %@", trId);
            NSLog(@"[2]success fidoRegistWithDelegate svcTrId : %@", svcTrId);

            /*
             * 파이도 실행
             */
            dispatch_async(dispatch_get_main_queue(), ^{
                [[OnePassManager sharedSingleton] requestWithTrId:trId];
            });
            
        }
        else {
            [FIDOController fidoErrorMessage:@"생체인증 등록에 실패하였습니다."];
        }
        
    } failBlock:^(id  _Nullable result) {
       NSLog(@"error fidoRegistWithDelegate : %@", result);
        [FIDOController fidoErrorMessage:@"생체인증 등록에 실패하였습니다."];
    }];
}

/*
 * FIDO 인증
 */
- (void)fidoAuthWithDelegate:(id<FIDOControllerDelegate>)delegate completion:(completionFidoBlock)completion {
    self.m_completion = completion;

    if ( ![FIDOController canFIDOMessage] ) {
        return;
    }
    
    NSLog(@"start fidoAuthWithDelegate");
    
    __weak typeof(self) weakSelf = self;
    self.m_fidoControllerDelegate = delegate;
    
    NSMutableDictionary *info = [self defaultDataWithCommand:@"requestServiceAuth"];
    
    //rtoken 추가
    NSString *encToken = [FileUtil getObjectForKey:CONST_KEY_AUTO_LOGIN_TOKEN];
    NSString *decToken = [AESUtil toDecryptWithString:encToken];
    [info setValue:decToken forKey:@"rtoken"];
    
    [NetAPIClient requestFidoAPI:CONST_URL_FIDO_TR_ID parameters:info successBlock:^(id  _Nullable result) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        NSData *data = [result dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            
        NSLog(@"[1]success fidoAuthWithDelegate : %@", dict);
        
        NSString *resultCode = [dict objectForKey:@"resultCode"];
        if ( [resultCode isEqualToString:FIDO_SUCCESS_CODE] ) {
            NSString *trId = [[dict objectForKey:@"resultData"] objectForKey:@"trId"];
            
            NSString *svcTrId = [dict objectForKey:@"svcTrId"];
            strongSelf.m_svcTrId = svcTrId;
            
            NSLog(@"[2]success fidoAuthWithDelegate trId : %@", trId);
            NSLog(@"[2]success fidoAuthWithDelegate svcTrId : %@", svcTrId);

            /*
             * 파이도 실행
             */
            dispatch_async(dispatch_get_main_queue(), ^{
                [[OnePassManager sharedSingleton] requestWithTrId:trId];
            });
        }
        else {
            [FIDOController fidoErrorMessage:@"생체인증에 실패하였습니다."];
        }
        
    } failBlock:^(id  _Nullable result) {
       NSLog(@"error fidoAuthWithDelegate : %@", result);
        [FIDOController fidoErrorMessage:@"생체인증에 실패하였습니다."];
    }];
}

/*
 * FIDO 해지
 */
- (void)fidoDereigstWithDelegate:(id<FIDOControllerDelegate>)delegate completion:(completionFidoBlock)completion {
    self.m_completion = completion;

    if ( ![FIDOController canFIDOMessage] ) {
        return;
    }
    
    NSLog(@"start fidoDereigstWithDelegate");
    
    __weak typeof(self) weakSelf = self;
    self.m_fidoControllerDelegate = delegate;
    
    NSMutableDictionary *info = [self defaultDataWithCommand:@"requestServiceRelease"];
    //rtoken 추가
    NSString *encToken = [FileUtil getObjectForKey:CONST_KEY_AUTO_LOGIN_TOKEN];
    NSString *decToken = [AESUtil toDecryptWithString:encToken];
    [info setValue:decToken forKey:@"rtoken"];
    
    [NetAPIClient requestFidoAPI:CONST_URL_FIDO_TR_ID parameters:info successBlock:^(id  _Nullable result) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        NSData *data = [result dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            
        NSLog(@"[1]success fidoDereigstWithDelegate : %@", dict);
        
        NSString *resultCode = [dict objectForKey:@"resultCode"];
        if ( [resultCode isEqualToString:FIDO_SUCCESS_CODE] ) {
            NSString *trId = [[dict objectForKey:@"resultData"] objectForKey:@"trId"];
            
            NSString *svcTrId = [dict objectForKey:@"svcTrId"];
            strongSelf.m_svcTrId = svcTrId;
            
            NSLog(@"[2]success fidoDereigstWithDelegate trId : %@", trId);
            NSLog(@"[2]success fidoDereigstWithDelegate svcTrId : %@", svcTrId);

           /*
            * 파이도 실행
            */
           dispatch_async(dispatch_get_main_queue(), ^{
               [[OnePassManager sharedSingleton] requestWithTrId:trId];
           });
            
        }
        else {
            [FIDOController fidoErrorMessage:@"생체인증 해지에 실패하였습니다."];
        }
        
    } failBlock:^(id  _Nullable result) {
       NSLog(@"error fidoDereigstWithDelegate : %@", result);
        [FIDOController fidoErrorMessage:@"생체인증 해지에 실패하였습니다."];
    }];
}

/*
 * 앱서버 검증
 */
- (void)fidoVerifyOnSuccess:(void(^)(void))success {
    NSMutableDictionary *info = [self defaultDataWithCommand:@"trResultConfirm"];
    [info setObject:self.m_svcTrId forKey:@"svcTrId"];
    
    //rtoken 추가
    NSString *encToken = [FileUtil getObjectForKey:CONST_KEY_AUTO_LOGIN_TOKEN];
    NSString *decToken = [AESUtil toDecryptWithString:encToken];
    [info setValue:decToken forKey:@"rtoken"];
    
    [NetAPIClient requestFidoAPI:CONST_URL_FIDO_TR_ID parameters:info successBlock:^(id  _Nullable result) {
        
        NSData *data = [result dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        NSString *resultCode = [dict objectForKey:@"resultCode"];
        NSString *trStatus = [[dict objectForKey:@"resultData"] objectForKey:@"trStatus"];
        if ( [resultCode isEqualToString:FIDO_SUCCESS_CODE] && [trStatus isEqualToString:@"1"] ) {
            NSLog(@"success fidoVerify : %@", dict);
            
             NSString *accessToken = [dict objectForKey:@"accessToken"];
             NSString *csno = [dict objectForKey:@"prsnCorpCsno"];
             NSString *name = [dict objectForKey:@"name"];
             NSString *rtoken = [dict objectForKey:@"rtoken"];
             [SharedData sharedInstance].m_accessToken = accessToken;
        
             LoginResultVO *loginVo = [[SharedData sharedInstance] getLoginResultVO];
             loginVo.accessToken = accessToken;
             loginVo.token = rtoken;
             loginVo.nameKr = name;
             loginVo.csno = csno;
  
            
            if ( success ) {
                success();
            }
        }
        else {
             [FIDOController fidoErrorMessage:@"생체인증 검증에 실패하였습니다."];
        }
        
    } failBlock:^(id  _Nullable result) {
       NSLog(@"error fidoVerify : %@", result);
       [FIDOController fidoErrorMessage:@"생체인증 검증에 실패하였습니다."];
    }];
}



#pragma mark - OnePassMangerAppDelegate
- (void)receiveOnePassMessage:(NSDictionary *)msgDict {
    NSLog(@"receiveOnePassMessage : %@", msgDict);
    
    int resultCode = [[msgDict objectForKey:ONEPASS_KEY_RESULT_CODE] intValue];
    
    /*
     * 성공
     */
    if ( ![self.m_svcTrId validation] ) {
        [FIDOController fidoErrorMessage:@"생체인증 장치를 사용할 수 없습니다.\n확인후 다시 시도해 주세요."];
    }
    else if ( resultCode == 0 || resultCode == 1200  ) {
        
        NSLog(@"[1]receiveOnePassMessage success!!!");
                
        if ( [self.m_svcTrId validation] ) {
            
            __weak typeof(self) weakSelf = self;
            [self fidoVerifyOnSuccess:^{
                __strong typeof(weakSelf) strongSelf = weakSelf;

                NSLog(@"[2]receiveOnePassMessage success!!!");

                if ( [strongSelf.m_fidoControllerDelegate respondsToSelector:@selector(fidoReceivedMessage:)] ) {
                    NSLog(@"fidoReceivedMessage success!!!");
                    [strongSelf.m_fidoControllerDelegate fidoReceivedMessage:msgDict];
                    
                }
                
                if ( strongSelf.m_completion ) {
                     NSLog(@"m_completion success!!!");
                    strongSelf.m_completion(YES , msgDict);
                   
                }
            }];
        }
        else {
            [FIDOController fidoErrorMessage:@"생체인증 사용중에 오류가 발새하였습니다.\n다시 시도해 주세요."];
            if ( self.m_completion ) {
                self.m_completion(NO , nil);
            }
        }
    }
    else if ( resultCode == ERROR_WRAPKEY_CD.intValue ) {
        [FIDOController fidoErrorMessage:ERROR_WRAPKEY_MSG];
        if ( self.m_completion ) {
            self.m_completion(NO , nil);
        }
    }
    else {
        [FIDOController fidoErrorMessage:@"생체인증 장치를 사용할 수 없습니다.\n확인후 다시 시도해 주세요."];
        if ( self.m_completion ) {
            self.m_completion(NO , nil);
        }
    }
    
}

#pragma mark - 알림박스
+ (void)fidoErrorMessage:(NSString *)message {
    //[FileUtil removeObjectForKey:CONST_KEY_FIDO_USE_YN];
    //[FileUtil saveObject:LOGIN_TYPE_PASSWORD_AUTH forKey:CONST_KEY_LOGIN_TYPE];
    [HCAlertView alertWithTtile:@"생체인증 에러" message:message confirmButtonTitle:@"확인" cancelButtontitle:nil completion:nil];
}

@end
