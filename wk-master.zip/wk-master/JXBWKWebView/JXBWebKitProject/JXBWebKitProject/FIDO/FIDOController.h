

#import <Foundation/Foundation.h>
#import <public_onepass/OnePassManager.h>
#import <public_onepass/OnePassUtil.h>

#define CAN_FIDO 0

NS_ASSUME_NONNULL_BEGIN

typedef void (^completionFidoBlock)(BOOL success,  NSDictionary * _Nullable result);


@protocol FIDOControllerDelegate <NSObject>

@required
- (void)fidoReceivedMessage:(NSDictionary *)info; //파이도 실행이 성공했을때만..

@end


@interface FIDOController : NSObject <OnePassMangerAppDelegate>




+ (instancetype)sharedInstance;

/*
 * FIDO 로그인유형 유무
 */
+ (BOOL)fidoLoginType;

/*
 * FIDO 사용유무
 */
+ (BOOL)fidoUseYn;

/*
 * FIDO 사용가능 단말인지 체크
 */
+ (NSInteger)fidoCheckDevice;

/*
 * 생체인증 지원단말 체크
 */
+ (BOOL)canDevice;
+ (BOOL)canDeviceMessage;

/*
 * OS잠금설정 체크
 */
+ (BOOL)isSetPasscode;
+ (BOOL)isSetPasscodeMessage;

/*
 * 생체인증 등록 체크
 */
+ (BOOL)isEnrolledAuth;
+ (BOOL)isEnrolledAuthMessage;

/*
 * 파이도인증 가능여부 체크
 */
+ (BOOL)canFIDO;
+ (BOOL)canFIDOMessage;


/*
 * 초기화
 */
- (void)initilaize;

/*
 * FIDO 등록
 */
- (void)fidoRegistWithDelegate:(_Nullable id<FIDOControllerDelegate>)delegate completion:(completionFidoBlock)completion;

/*
 * FIDO 인증
 */
- (void)fidoAuthWithDelegate:(_Nullable id<FIDOControllerDelegate>)delegate completion:(completionFidoBlock)completion;

/*
 * FIDO 해지
 */
- (void)fidoDereigstWithDelegate:(_Nullable id<FIDOControllerDelegate>)delegate completion:(completionFidoBlock)completion;

@end

NS_ASSUME_NONNULL_END
