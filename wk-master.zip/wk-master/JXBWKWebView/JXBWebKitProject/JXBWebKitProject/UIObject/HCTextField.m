

#import "HCTextField.h"

@interface HCTextField()

@property (nonatomic, copy) HCTextFieldDidChangeBlock m_didChangedCallBack;
@property (nonatomic, copy) HCTextFieldDidBeginBlock m_didBeginedCallBack;

@end


@implementation HCTextField

- (void)awakeFromNib {
    [super awakeFromNib];
    
    [self addTarget:self action:@selector(didEdittingChanged:) forControlEvents:UIControlEventEditingChanged];
    [self addTarget:self action:@selector(didTouched:) forControlEvents:UIControlEventEditingDidBegin];

}

- (void)didEdittingChanged:(UITextField *)textField {
    if ( self.m_didChangedCallBack ) {
        self.m_didChangedCallBack(self);
    }
}

- (void)didTouched:(UITextField *)textField {
    if ( self.m_didBeginedCallBack ) {
        self.m_didBeginedCallBack(self);
    }
}


- (void)onEditingCallBack:(HCTextFieldDidChangeBlock)callBack {
    self.m_didChangedCallBack = callBack;
}

- (void)onBeginCallBack:(HCTextFieldDidBeginBlock)callBack {
    self.m_didBeginedCallBack = callBack;
}

@end
