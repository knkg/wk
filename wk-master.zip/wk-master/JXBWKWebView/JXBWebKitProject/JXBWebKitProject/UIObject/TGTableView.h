

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol TGTableViewDataSource <NSObject>

@required
- (void)registerTableViewCell;
- (NSMutableArray *)togglTableViewSectionData;
- (NSMutableArray *)togglTableViewDataInSection;

@end

@protocol TGTableViewDelegate <NSObject>

@required
- (void)togglTableViewDidSelectRowAtIndexPath:(NSIndexPath *)indexPath;

@optional
- (void)togglTableViewDidSelectSection:(NSInteger)section;

@end


@interface TGTableView : UITableView<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, weak) id<TGTableViewDataSource> m_TGTableViewDataSource;
@property (nonatomic, weak) id<TGTableViewDelegate> m_TGTableViewDelegate;

@property (nonatomic, readonly, getter=getArraySection) NSArray *m_arraySection;
@property (nonatomic, readonly, getter=getArrayDataInSection) NSArray *m_arrayDataInSection;

//@property (nonatomic, strong) NSNumber *m_selectedSection;

- (void)toggleTableViewConfiguration;
- (void)registerNibName:(NSString *)nibName reuseIdentifier:(NSString *)reuseIdentifier;
- (void)registerClassName:(NSString *)className reuseIdentifier:(NSString *)reuseIdentifier;
- (void)createGroupTableIndexPathInfo;

- (void)didSelectSection:(NSInteger)section;
- (void)onToggledWithSection:(NSInteger)section;

@end

NS_ASSUME_NONNULL_END
