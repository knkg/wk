

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^HCTextFieldDidChangeBlock)(UITextField *textField);
typedef void(^HCTextFieldDidBeginBlock)(UITextField *textField);

@interface HCTextField : UITextField

- (void)onEditingCallBack:(HCTextFieldDidChangeBlock)callBack;
- (void)onBeginCallBack:(HCTextFieldDidBeginBlock)callBack;

@end

NS_ASSUME_NONNULL_END
