
#import "HCButton.h"

@interface HCButton()

@property (nonatomic, copy) HCButtonEventListener listener;


@end


@implementation HCButton

- (instancetype)initWithFrame:(CGRect)frame {
    if ( self = [super initWithFrame:frame] ) {
        [self addTarget:self action:@selector(buttonTouchedEvent:) forControlEvents:UIControlEventTouchUpInside];
        return self;
    }
    
    return nil;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self addTarget:self action:@selector(buttonTouchedEvent:) forControlEvents:UIControlEventTouchUpInside];
}

- (void) onTouchEventListener:(HCButtonEventListener)listener {
    self.listener = listener;
}

- (void) buttonTouchedEvent:(HCButton *)button {
    if ( self.listener ) {
        self.listener(self);
    }
}

@end
