

#import <UIKit/UIKit.h>

typedef void (^HCButtonEventListener)(id _Nullable button);


NS_ASSUME_NONNULL_BEGIN

@interface HCButton : UIButton

- (void) onTouchEventListener:(HCButtonEventListener)listener;

@end

NS_ASSUME_NONNULL_END
