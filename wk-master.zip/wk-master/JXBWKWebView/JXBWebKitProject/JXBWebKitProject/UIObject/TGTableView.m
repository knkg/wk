

#import "TGTableView.h"

@interface TGTableView()

@property (nonatomic, strong) NSArray *arraySection;
@property (nonatomic, strong) NSArray *arrayDataInSection;
@property (nonatomic, strong) NSMutableArray *arrayIndexPathInfo;

@end

@implementation TGTableView

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    if ( self = [super initWithFrame:frame style:style] ) {
        return self;
    }
    
    return nil;
}


- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)toggleTableViewConfiguration {
    
    //TableViewCell 셋팅
    if ( [self.m_TGTableViewDataSource respondsToSelector:@selector(registerTableViewCell)] ) {
        [self.m_TGTableViewDataSource registerTableViewCell];
    }
    
    //섹션헤더 셋팅
    if ( [self.m_TGTableViewDataSource respondsToSelector:@selector(togglTableViewSectionData)] ) {
        NSMutableArray *array = [self.m_TGTableViewDataSource togglTableViewSectionData];
        self.arraySection = [NSArray arrayWithArray:array];
    }
    
    //섹션헤더 안에 들어갈 데이타 셋팅
    if ( [self.m_TGTableViewDataSource respondsToSelector:@selector(togglTableViewDataInSection)] ) {
        NSMutableArray *array = [self.m_TGTableViewDataSource togglTableViewDataInSection];
        self.arrayDataInSection = [NSArray arrayWithArray:array];

    }
    
    if ( self.m_arraySection.count > 0 && self.m_arrayDataInSection.count > 0 ) {
        [self createGroupTableIndexPathInfo];
        
        [self setDataSource:self];
        [self setDelegate:self];
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.m_arraySection.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ( self.arrayIndexPathInfo.count > section ) {
        NSIndexPath *indexPath = [self.arrayIndexPathInfo objectAtIndex:section];
        return indexPath.row;
    }
    
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    return nil;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ( [self.m_TGTableViewDelegate respondsToSelector:@selector(togglTableViewDidSelectRowAtIndexPath:)] ) {
        [self.m_TGTableViewDelegate togglTableViewDidSelectRowAtIndexPath:indexPath];
    }
}



#pragma mark - Custom Mehtod
- (void)registerNibName:(NSString *)nibName reuseIdentifier:(NSString *)reuseIdentifier {
    UINib *nib = [UINib nibWithNibName:nibName bundle:nil];
    [self registerNib:nib forCellReuseIdentifier:reuseIdentifier];
}

- (void)registerClassName:(NSString *)className reuseIdentifier:(NSString *)reuseIdentifier {
    [self registerClass:NSClassFromString(className) forCellReuseIdentifier:reuseIdentifier];
}

- (void)createGroupTableIndexPathInfo {
    
    if ( !self.arrayIndexPathInfo ) {
        self.arrayIndexPathInfo = [[NSMutableArray alloc] init];
    }
    else {
        if ( self.arrayIndexPathInfo.count > 0 ) {
            [self.arrayIndexPathInfo removeAllObjects];
        }
    }
    
    for ( NSInteger section = 0; section < self.m_arraySection.count; section++ ) {
        NSIndexPath *addIndexPaths = [NSIndexPath indexPathForRow:0 inSection:section];
        [self.arrayIndexPathInfo addObject:addIndexPaths];
    }
}

- (void)didSelectSection:(NSInteger)section {
    if ( [self.m_TGTableViewDelegate respondsToSelector:@selector(togglTableViewDidSelectSection:)] ) {
        [self.m_TGTableViewDelegate togglTableViewDidSelectSection:section];
    }
}

- (void)onToggledWithSection:(NSInteger)section {
    NSIndexPath *selectedIndexPath = [self.arrayIndexPathInfo objectAtIndex:section];
    
    //섹션이 열림 상태가 아니라면 열어줌.
    if ( selectedIndexPath.row == 0 ) {
        
        //이전에 열린섹션은 닫아줌.
//        if ( self.m_selectedSection ) {
//            NSInteger oSection = self.m_selectedSection.integerValue;
//            NSIndexPath *oIndexPath = [self.m_arrayIndexPathInfo objectAtIndex:oSection];
//            [self closeToSection:oSection indexPath:oIndexPath];
//        }
        
        [self openToSection:section indexPath:selectedIndexPath];
        
        //현재 선택한 섹션을 저장함.
//        self.m_selectedSection = [NSNumber numberWithInteger:section];
    }
    else {
        [self closeToSection:section indexPath:selectedIndexPath];
    }
}

- (void)closeToSection:(NSInteger)section indexPath:(NSIndexPath *)indexPath {
    //열려있는 상태면..
    if ( indexPath.row > 0 ) {
        NSIndexPath *newIndexPath = [NSIndexPath indexPathForRow:0 inSection:section];
        [self.arrayIndexPathInfo replaceObjectAtIndex:section withObject:newIndexPath];
        
        NSMutableArray  *arrIndexPaths = [[NSMutableArray alloc] init];
        for ( NSInteger arrIndex = 0; arrIndex < indexPath.row; arrIndex++ ) {
            NSIndexPath *indexPaths = [NSIndexPath indexPathForRow:arrIndex inSection:section];
            [arrIndexPaths addObject:indexPaths];
        }
        
        [self deleteRowsAtIndexPaths:arrIndexPaths withRowAnimation:UITableViewRowAnimationTop];
    }
}

- (void)openToSection:(NSInteger)section indexPath:(NSIndexPath *)indexPath {
    //닫혀있는 상태면..
    if ( indexPath.row == 0 ) {
        NSArray *arrDatas = [self.m_arrayDataInSection objectAtIndex:section];
        NSIndexPath *newIndexPath = [NSIndexPath indexPathForRow:arrDatas.count inSection:section];
        [self.arrayIndexPathInfo replaceObjectAtIndex:section withObject:newIndexPath];
        
        NSMutableArray  *arrIndexPaths = [[NSMutableArray alloc] init];
        for ( NSInteger arrIndex = 0; arrIndex < arrDatas.count; arrIndex++ ) {
            NSIndexPath *indexPaths = [NSIndexPath indexPathForRow:arrIndex inSection:section];
            [arrIndexPaths addObject:indexPaths];
        }
        [self insertRowsAtIndexPaths:arrIndexPaths withRowAnimation:UITableViewRowAnimationTop];
    }
}

#pragma mark - getter
- (NSArray *)getArraySection {
    return self.arraySection;
}

- (NSArray *)getArrayDataInSection {
    return self.arrayDataInSection;
}

@end
