
/* Sample...
 //    NSString  * sourceString = @"test";
 //
 //    NSLog(@"sourceString : %@", sourceString);
 //
 //    NSString *enc = [AESUtil toAES256StringFromSourceString:sourceString];
 //    NSLog(@"enc : %@", enc);
 //
 //
 //    NSString *dec = [AESUtil toSourceStringFromAES256String:enc];
 //    NSLog(@"dec : %@", dec);
 */


#import "AESUtil.h"

#import "NSData+Addition.h"
#import "NSString+Addition.h"

#import "DeviceUtil.h"
//#import "FileUtil.h"
#import "SharedData.h"



@implementation AESUtil

+ (NSString *)toEncryptWithString:(NSString *)sourceString {
//    NSLog(@"sourceString : %@", sourceString);

    NSString *keyString = [DeviceUtil getUUID];
    
    
    NSData *data = [sourceString dataUsingEncoding:NSUTF8StringEncoding];
    NSData *encData = [data AES256EncryptWithKey:keyString];
    NSString *strBase64Encode = [encData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
    
//    NSLog(@"AES256String : %@", strBase64Encode);
    
    return strBase64Encode;
}

+ (NSString *)toDecryptWithString:(NSString *)AES256String {
//    NSLog(@"AES256String : %@", AES256String);

    NSString *keyString = [DeviceUtil getUUID];
    
    NSData *base64Data = [[AES256String dataUsingEncoding:NSUTF8StringEncoding] initWithBase64EncodedString:AES256String options:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSData *decData = [base64Data AES256DecryptWithKey:keyString];
    NSString *sourceString = [[NSString alloc] initWithData:decData encoding:NSUTF8StringEncoding];
    
//    NSLog(@"SourceString : %@", sourceString);
    
    return sourceString;
}

@end
