

#import "FileUtil.h"

@implementation FileUtil

#pragma mark - NSFileManager Handler

/**
 * @breif   도큐먼트경로
 * @return  NSString
 */
+ (NSString *)fileGetDocumentPath {
    NSArray *array = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    if ( array ) {
        NSString *path = [array objectAtIndex:0];
        return path;
    }
    
    return nil;
}

/**
 * @breif   파일/폴더명을 포함한 경로
 * @param   item 파일명/폴더명 경로
 * @return  NSString
 */
+ (NSString *)fileDocumentItemPath:(NSString *)item {
    NSString *path = [FileUtil fileGetDocumentPath];
    NSString *filePath = [path stringByAppendingPathComponent:[item lastPathComponent]];
    NSLog(@"knkg fileDocumentItemPath path= %@\n", path);
    NSLog(@"knkg fileDocumentItemPath filePath= %@\n", filePath);
    
    return filePath;
}

/**
 * @breif   파일/폴더 체크
 * @param   item 파일명/폴더명
 * @return  BOOL
 */
+ (BOOL)fileIsExistItem:(NSString *)item {
    NSLog(@"knkg fileIsExistItem param=%@\n", item);
    NSString *path = [FileUtil fileDocumentItemPath:item];
    NSLog(@"knkg fileIsExistItem path=%@\n", path);
    BOOL success = [[NSFileManager defaultManager] fileExistsAtPath:path];
    if ( success ) {
        return YES;
    }

    return NO;
}

/**
 * @breif   파일/폴더 삭제
 * @param   item 파일명/폴더명
 * @return  BOOL
 */
+ (BOOL)fileDeleteItem:(NSString *)item {
    
    if ( [self fileIsExistItem:item] ) {
        NSError *error;
        NSString *path = [FileUtil fileDocumentItemPath:item];
        BOOL success = [[NSFileManager defaultManager] removeItemAtPath:path error:&error];
        if ( success ) {
            return YES;
        }
        
        NSLog(@"deleteItem Error : %@", error.description);
    }
    
    return NO;
}

/**
 * @breif   폴더생성
 * @param   item 폴더명
 * @return  BOOL
 */
+ (BOOL)fileCreateDirectory:(NSString *)item {
    if ( ![self fileIsExistItem:item] ) {
        NSError *error;
        NSString *path = [FileUtil fileDocumentItemPath:item];
        BOOL success = [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:&error];
        if ( success ) {
            return YES;
        }
        
        NSLog(@"makeDir Error : %@", error.description);
        return NO;
    }
    
    return YES;
}

/**
 * @breif   파일생성
 * @param   item 파일명
 * @param   contents 파일데이타
 * @return  BOOL
 */
+ (BOOL)fileSaveItem:(NSString *)item contents:(NSData *)contents {
    if ( [self fileIsExistItem:item] ) {
        [self fileDeleteItem:item];
    }

    NSString *path = [FileUtil fileDocumentItemPath:item];
    NSLog(@"knkg fileSaveItem item= %@\n", item);
    NSLog(@"knkg fileSaveItem path= %@\n", path);
    NSLog(@"knkg fileSaveItem contents= %@\n", contents);
    BOOL success = [[NSFileManager defaultManager] createFileAtPath:path contents:contents attributes:nil];
    if ( success ) {
        return YES;
    }
    
    NSLog(@"saveItem Error");
    
    return NO;
}

/**
 * @breif   아이템 불러오기
 * @param   path 아이템경로
 * @return  id
 */
+ (id)fileLoadItemPath:(NSString *)path {
    NSString *documentItemPath = [FileUtil fileDocumentItemPath:path];
    if ( [FileUtil fileIsExistItem:documentItemPath] ) {
        NSData *data = [NSData dataWithContentsOfFile:path];
        return data;
    }
    
    return nil;
}

/**
 * @breif   아이템 이동 또는 이름변경
 * @param   sourcePath 원본데이터 경로
 * @param   destPath   타겟데이터 경로
 * @return  BOOL
 */
+ (BOOL)fileMoveItemPath:(NSString *)sourcePath destPath:(NSString *)destPath {
    NSError *error;
    NSString *fromPath = [FileUtil fileDocumentItemPath:sourcePath];
    NSString *toPath = [FileUtil fileDocumentItemPath:destPath];
    BOOL success = [[NSFileManager defaultManager] moveItemAtPath:fromPath toPath:toPath error:&error];
    if ( success ) {
        return YES;
    }
    
    return NO;
}

/**
 * @breif   아이템 복사
 * @param   sourcePath 원본데이터 경로
 * @param   destPath   타겟데이터 경로
 * @return  BOOL
 */
+ (BOOL)fileCopyItemPath:(NSString *)sourcePath destPath:(NSString *)destPath {
    NSError *error;
    NSString *fromPath = [FileUtil fileDocumentItemPath:sourcePath];
    NSString *toPath = [FileUtil fileDocumentItemPath:destPath];
    BOOL success = [[NSFileManager defaultManager] copyItemAtPath:fromPath toPath:toPath error:&error];
    if ( success ) {
        return YES;
    }
    
    return NO;
}

/**
 * @breif   파일또는 폴더 목록 가져오기
 * @param   path 경로
 * @return  NSArray
 */
+ (NSArray *)fileArrayItemsPath:(NSString *)path {
    NSError *error;
    NSString *directoryPath = [FileUtil fileDocumentItemPath:path];
    NSArray *arrayContents = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:directoryPath error:&error];
    return arrayContents;
}

#pragma mark - NSKeyedArchiver Handler

/**
 * @breif   NSKeyedArchiver
 * @param   object 저장데이터
 * @param   keyString 키값
 */
+ (void)archivedObject:(id)object forKey:(NSString *)keyString {
//    NSError *error;
//    NSData *data;
    
//    if (@available(iOS 11.0, *)) {
//        data = [NSKeyedArchiver archivedDataWithRootObject:object requiringSecureCoding:NO error:&error];
//    } else {
//        data = [NSKeyedArchiver archivedDataWithRootObject:object];
//    }
    
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:object];
    
    
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:keyString];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

/**
 * @breif   NSKeyedArchiver
 * @param   keyString 키값
 * @return  id
 */
//+ (id)archivedObjectForKey:(NSString *)keyString class:(nullable Class)archivedClass {
+ (id)archivedObjectForKey:(NSString *)keyString {

//    NSError *error;
//    id data;
    id object = [[NSUserDefaults standardUserDefaults] objectForKey:keyString];
    
//    if ( [NSKeyedUnarchiver respondsToSelector:@selector(unarchivedObjectOfClass:fromData:error:)] ) {
//        data = [NSKeyedUnarchiver unarchivedObjectOfClass:archivedClass fromData:object error:&error];
//    }
//    else {
//        if ( [NSKeyedUnarchiver respondsToSelector:@selector(unarchiveObjectWithData:)] ) {
//            data = [NSKeyedUnarchiver unarchiveObjectWithData:object];
//        }
//    }
    
    
    id data = [NSKeyedUnarchiver unarchiveObjectWithData:object];
    
    return data;
}

#pragma mark - UserDefaults Handler

/**
 * @breif   NSUserDefaults
 * @param   keyString 키
 */
+ (id)getObjectForKey:(NSString *)keyString {
   id object =  [[NSUserDefaults standardUserDefaults] objectForKey:keyString];
    return object;
}

/**
 * @breif   NSUserDefaults
 * @param   object 저장데이터
 * @param   keyString 키값
 */
+ (void)saveObject:(id)object forKey:(NSString *)keyString {
    [[NSUserDefaults standardUserDefaults] setObject:object forKey:keyString];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

/**
 * @breif   NSUserDefaults
 * @param   keyString 키값
 */
+ (void)removeObjectForKey:(NSString *)keyString {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:keyString];
    [[NSUserDefaults standardUserDefaults] synchronize];
}



@end
