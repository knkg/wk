

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class AppDelegate;
@interface CommonUtil : NSObject

//+ (void)toastMessage:(NSString *)message;
+ (UIImage *)imageFromView:(UIView *)view;

+ (UIImageView *)imageViewForScreenBlock;

+ (void)regsterTableViewCellNibName:(NSString *)nibName tableView:(UITableView *)tableView identifier:(NSString *)identifier;
+ (id) loadNibNamed:(NSString *)nibName className:(NSString *)className;
+ (instancetype) storyboardName:(NSString *)storyboardName identifier:(nullable NSString *)identifier;

+ (CGFloat)heightForTopPadding;
+ (CGFloat)heightForBottomPadding;
+ (CGFloat)heightForMainContent;
    
+ (AppDelegate *)appDelegate;
+ (void)toastMessage:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
