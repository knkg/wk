

#import "DeviceUtil.h"
#import "AESUtil.h"
#import "KeychainItemWrapper.h"
#import <sys/utsname.h>
#import "NSString+Addition.h"



@implementation DeviceUtil

+ (NSString*) getIDFV {
    NSString *idfv = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    return idfv;
}

+ (NSString*) getNewUUID {
    CFUUIDRef uuidRef = CFUUIDCreate(NULL);
    CFStringRef uuidStringRef = CFUUIDCreateString(NULL, uuidRef);
    CFRelease(uuidRef);
    
    NSString *uuid = [NSString stringWithString:(__bridge NSString *) uuidStringRef];
    
    return uuid;
}

+ (NSString*) getUUID {
    // initialize keychaing item for saving UUID.
     
    NSString *identifier = [NSString stringWithFormat:@"%@.uuid", [DeviceUtil appBundleIdentifier]];
    
    KeychainItemWrapper *wrapper = [[KeychainItemWrapper alloc] initWithIdentifier:identifier accessGroup:nil];
    NSString *uuid = [wrapper objectForKey:(__bridge id)(kSecAttrAccount)];
    
    if( uuid == nil || uuid.length == 0) {
        // if there is not UUID in keychain, make UUID and save it.
//        CFUUIDRef uuidRef = CFUUIDCreate(NULL);
//        CFStringRef uuidStringRef = CFUUIDCreateString(NULL, uuidRef);
//        CFRelease(uuidRef);
//
//        uuid = [NSString stringWithString:(__bridge NSString *) uuidStringRef];
//        CFRelease(uuidStringRef);
        // save UUID in keychain
        
        uuid = [DeviceUtil getNewUUID];
        
        [wrapper setObject:uuid forKey:(__bridge id)(kSecAttrAccount)];
    }

    return uuid;
}

+ (NSString *) keychainDataWithKey:(NSString *)keyString {
    NSString *identifier = [NSString stringWithFormat:@"%@.%@", [DeviceUtil appBundleIdentifier], keyString];
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:identifier accessGroup:nil];
    NSString *data = [keychain objectForKey:(__bridge id)(kSecAttrAccount)];
    
    return data;
}

+ (void ) keychainUpdateDataWithData:(NSString *)data forKey:(NSString *)keyString {
    NSString *identifier = [NSString stringWithFormat:@"%@.%@", [DeviceUtil appBundleIdentifier], keyString];
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:identifier accessGroup:nil];
    [keychain resetKeychainItem];
    [keychain setObject:data forKey:(__bridge id)(kSecAttrAccount)];
}

+ (void) keychainResetDataWithKey:(NSString *)keyString {
    NSString *identifier = [NSString stringWithFormat:@"%@.%@", [DeviceUtil appBundleIdentifier], keyString];
    KeychainItemWrapper *keychain = [[KeychainItemWrapper alloc] initWithIdentifier:identifier accessGroup:nil];
    [keychain resetKeychainItem];
}

+ (NSString *) appVersion {
    NSString *ver = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    return ver;
}

+ (NSString *) appBuildVersion {
    NSString *ver = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
    return ver;
}

+ (NSString *) appBundleIdentifier {
    NSString *bundleIdentifier = [[NSBundle mainBundle] bundleIdentifier];
    return bundleIdentifier;
}

+ (NSString *)osVersion {
    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
    return [NSString stringWithFormat:@"%@", [NSNumber numberWithFloat:version]];
}

+ (NSString *)phoneModel {
    struct utsname systemInfo;
    uname(&systemInfo);
    
    NSString *model = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    return model;
}


/*
 * 화면잠금 상태감지 Observer등록
 */
+ (void)registerForDeviceLockNotification {
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    deviceLockStateChanged,
                                    CFSTR("com.apple.springboard.lockstate"),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    NULL,
                                    deviceLockStateChanged,
                                    CFSTR("com.apple.springboard.lockcomplete"),
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
}

/*
 * 화면잠금 상태감지 콜백
 */
static void deviceLockStateChanged(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userIinfo) {
    NSString *lockState = (__bridge NSString *)name;
    NSLog(@"Darwin notification Name - %@", lockState);
    
    if ( [lockState isEqualToString:@"com.apple.springboard.lockcomplete"] ) {
        NSLog(@"DEVICE LOCKED");
    }
    else {
        NSLog(@"LOCK STATUS CHANGED");
    }
}



@end
