
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AESUtil : NSObject



/*
 * NSString -> AES256 암호화
 * @param 암호화할 문자열
 * @return AES256 암호화 문자열
 */
+ (NSString *)toEncryptWithString:(NSString *)sourceString;

/*
* AES256 암호화 -> NSString
* @param  AES256 암호화 문자열
* @return 복고화 문자열
*/
+ (NSString *)toDecryptWithString:(NSString *)AES256String;
    
@end

NS_ASSUME_NONNULL_END
