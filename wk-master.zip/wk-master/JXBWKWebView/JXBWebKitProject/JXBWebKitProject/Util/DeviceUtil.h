

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DeviceUtil : NSObject

+ (NSString*) getIDFV;

//기기 고유번호 가쟈오기 ( 단 매번 호출할경우 달라짐. )
+ (NSString*) getUUID;


//+ (NSString *) getWalletKey;
//+ (NSString *) getAESKey;
    
+ (NSString *) keychainDataWithKey:(NSString *)keyString;
+ (void ) keychainUpdateDataWithData:(NSString *)data forKey:(NSString *)keyString;
+ (void) keychainResetDataWithKey:(NSString *)keyString;

//새로운 UUID
+ (NSString*) getNewUUID;

//앱버전 가쟈오기
+ (NSString *) appVersion;

//빌드버전 가져오기
+ (NSString *) appBuildVersion;

//번들아이디 가쟈오기
+ (NSString *) appBundleIdentifier;

//디바이스 iOS버전 가쟈오기
+ (NSString *)osVersion;

//폰모델 가져오기
+ (NSString *)phoneModel;

//통신사 가져오기
//+ (NSString *)carrierName;

@end

NS_ASSUME_NONNULL_END
